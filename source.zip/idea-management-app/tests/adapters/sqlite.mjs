import { DatabaseSync } from "node:sqlite";
const raw = new DatabaseSync(":memory:");
const db = {
  async execAsync(sql) {
    raw.exec(sql);
  },
  async runAsync(sql, ...args) {
    return raw.prepare(sql).run(...args);
  },
  async getFirstAsync(sql, ...args) {
    return raw.prepare(sql).get(...args) ?? null;
  },
  async getAllAsync(sql, ...args) {
    return raw.prepare(sql).all(...args);
  },
  async withTransactionAsync(fn) {
    raw.exec("BEGIN");
    try {
      await fn();
      raw.exec("COMMIT");
    } catch (error) {
      raw.exec("ROLLBACK");
      throw error;
    }
  },
};
export async function openDatabaseAsync() {
  return db;
}
export { raw, db };

// Only native I/O is substituted; production repositories and real SQLite SQL run unchanged.
import { registerHooks } from "node:module";
import { readFileSync, existsSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import path from "node:path";
import ts from "typescript";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const native = {
  "expo-sqlite": "sqlite.mjs",
  "expo-file-system/legacy": "native.mjs",
  "expo-notifications": "native.mjs",
  "expo-sharing": "native.mjs",
  "react-native": "native.mjs",
};
registerHooks({
  resolve(specifier, context, next) {
    if (native[specifier])
      return {
        url: pathToFileURL(path.join(root, "tests/adapters", native[specifier]))
          .href,
        shortCircuit: true,
      };
    let candidate = specifier.startsWith("@/")
      ? path.join(root, "src", specifier.slice(2))
      : specifier.startsWith(".") && context.parentURL?.startsWith("file:")
        ? path.resolve(
            path.dirname(fileURLToPath(context.parentURL)),
            specifier,
          )
        : null;
    if (candidate) {
      for (const ext of ["", ".ts", ".tsx", ".mjs"])
        if (existsSync(candidate + ext) && !candidate.endsWith("/"))
          return {
            url: pathToFileURL(candidate + ext).href,
            shortCircuit: true,
          };
    }
    return next(specifier, context);
  },
  load(url, context, next) {
    if (url.endsWith(".ts") || url.endsWith(".tsx")) {
      const source = readFileSync(fileURLToPath(url), "utf8");
      return {
        format: "module",
        source: ts.transpileModule(source, {
          compilerOptions: {
            target: ts.ScriptTarget.ES2022,
            module: ts.ModuleKind.ESNext,
            jsx: ts.JsxEmit.ReactJSX,
          },
        }).outputText,
        shortCircuit: true,
      };
    }
    return next(url, context);
  },
});

import test, { before, beforeEach } from "node:test";
import assert from "node:assert/strict";
import { unzipSync, strFromU8 } from "fflate";
import { db, raw } from "./adapters/sqlite.mjs";
import { files, canceled } from "./adapters/native.mjs";
import { migrations, runMigrations } from "../src/db/migrations.ts";
import * as ideas from "../src/db/repositories/ideas.ts";
import * as creative from "../src/db/repositories/creative.ts";
import { addIdeaLink, listConnections } from "../src/db/repositories/links.ts";
import { exportAllData, singleIdeaMarkdown } from "../src/services/export.ts";
import { writeDb } from "../src/db/write.ts";

before(async () => {
  // Upgrade a real populated v1 vault, not just an empty v2 schema.
  raw.exec("PRAGMA foreign_keys=ON;");
  raw.exec(migrations[0]);
  raw.exec("UPDATE schema_meta SET version=1");
  raw
    .prepare(
      "INSERT INTO ideas(id,title,created_at,updated_at,last_touched_at,source_type,original_capture_id) VALUES('legacy','Existing user idea',1,1,1,'text','original')",
    )
    .run();
  raw
    .prepare(
      "INSERT INTO idea_blocks(id,idea_id,type,body_text,created_at,updated_at,is_original) VALUES('original','legacy','text','Keep this original',1,1,1)",
    )
    .run();
  await runMigrations();
  const legacy = await ideas.getIdea("legacy");
  assert.equal(legacy.title, "Existing user idea");
  assert.equal(legacy.is_starred, 0);
  assert.equal(legacy.energy, "steady");
  assert.equal(legacy.blocks[0].body_text, "Keep this original");
});
beforeEach(async () => {
  for (const table of [
    "ideas",
    "idea_fts",
    "projects",
    "time_capsules",
    "focus_sessions",
    "review_entries",
    "saved_views",
    "drafts",
    "app_settings",
    "tags",
  ])
    await db.runAsync(`DELETE FROM ${table}`);
  files.clear();
  canceled.length = 0;
});
const capture = (text = "A garden learning sensor") =>
  ideas.createIdeaFromCapture({ text });
test("migrations are idempotent after a populated v1 upgrade", async () => {
  await runMigrations();
  assert.equal(
    (await db.getFirstAsync("SELECT version FROM schema_meta")).version,
    2,
  );
  assert.ok((await ideas.listCategories()).length > 0);
});
test("capture + attachment + FTS are saved together", async () => {
  const id = await ideas.createIdeaFromCapture({
    text: "Garden sensor",
    attachment: {
      type: "image",
      uri: "file:///photo.jpg",
      mimeType: "image/jpeg",
    },
  });
  const idea = await ideas.getIdea(id);
  assert.equal(idea.blocks.length, 2);
  assert.equal(idea.attachments.length, 1);
  assert.equal((await ideas.searchIdeas("garden"))[0].id, id);
});
test("punctuation, quotes, SQL-looking text and Unicode search are safe", async () => {
  await capture("Café learning garden हिन्दी");
  await ideas.searchIdeas('" OR: * -');
  await ideas.searchIdeas("!?");
  await ideas.searchIdeas("'; DROP TABLE ideas; --");
  assert.equal((await ideas.searchIdeas("café")).length, 1);
  assert.equal((await ideas.searchIdeas("हिन्दी")).length, 1);
  assert.equal((await ideas.listIdeas()).length, 1);
});
test("collision creates a child and two lineage links atomically", async () => {
  const a = await capture("Garden sensor"),
    b = await capture("Question library");
  const child = await creative.createBranch({
    title: "Garden of questions",
    body: "Students tend a shared question garden.",
    parents: [a, b],
    source: "collision_lab",
  });
  assert.equal((await listConnections(child)).length, 2);
  assert.equal((await ideas.getIdea(child)).source_type, "collision_lab");
  assert.equal((await listConnections(a))[0].other_id, child);
});
test("invalid collision parent creates no orphaned child", async () => {
  const a = await capture();
  await assert.rejects(() =>
    creative.createBranch({
      title: "Invalid branch",
      body: "text",
      parents: [a, "missing"],
      source: "collision_lab",
    }),
  );
  assert.equal((await ideas.listIdeas()).length, 1);
});
test("a failed transaction rolls back and does not poison the write queue", async () => {
  await assert.rejects(() =>
    writeDb(async (d) => {
      await d.runAsync(
        "INSERT INTO app_settings(key,value) VALUES('rollback','yes')",
      );
      throw Error("rollback");
    }),
  );
  assert.equal(await creative.getSetting("rollback"), null);
  await creative.setSetting("next", "ok");
  assert.equal(await creative.getSetting("next"), "ok");
});
test("parallel captures and tasks serialize without nested transaction errors", async () => {
  const ids = await Promise.all(
    Array.from({ length: 12 }, (_, i) => capture(`Seed ${i}`)),
  );
  await Promise.all(ids.map((id) => creative.addAction(id, "A small step")));
  assert.equal((await ideas.listIdeas()).length, 12);
  assert.equal((await creative.listActions(ids[0])).length, 1);
});
test("tasks toggle, complete and reopen", async () => {
  const id = await capture();
  const task = await creative.addAction(id, "Sketch one screen");
  await creative.toggleAction(task);
  assert.ok((await creative.listActions(id))[0].done_at);
  await creative.toggleAction(task);
  assert.equal((await creative.listActions(id))[0].done_at, null);
});
test("experiment outcomes require observations", async () => {
  const id = await capture();
  const exp = await creative.createExperiment({
    ideaId: id,
    hypothesis: "People will use this",
    method: "Show a prototype",
    signal: "They can finish the task",
  });
  await assert.rejects(async () =>
    creative.updateExperiment(exp, "", "supported"),
  );
  await creative.updateExperiment(
    exp,
    "The first user got stuck.",
    "challenged",
  );
  assert.equal((await creative.listExperiments(id))[0].verdict, "challenged");
});
test("future capsules hide their letter and cannot be opened early", async () => {
  const id = await creative.createCapsule({
    title: "Later",
    body: "A letter",
    unlockAt: Date.now() + 86400000,
  });
  assert.equal((await creative.listCapsules())[0].body, "");
  await assert.rejects(() => creative.openCapsule(id));
  await db.runAsync(
    "UPDATE time_capsules SET unlock_at=? WHERE id=?",
    Date.now() - 1000,
    id,
  );
  assert.equal((await creative.openCapsule(id)).body, "A letter");
  assert.ok((await creative.listCapsules())[0].opened_at);
});
test("only one focus session can run; early completion records elapsed time", async () => {
  const id = await creative.startFocus({ intention: "Sketch", seconds: 300 });
  await assert.rejects(() =>
    creative.startFocus({ intention: "Second", seconds: 60 }),
  );
  await db.runAsync(
    "UPDATE focus_sessions SET started_at=?,ends_at=? WHERE id=?",
    Date.now() - 71000,
    Date.now() + 229000,
    id,
  );
  await creative.finishFocus(id, "One screen sketched");
  const [session] = await creative.focusHistory();
  assert.ok(session.elapsed_seconds >= 71 && session.elapsed_seconds <= 72);
  assert.equal(session.status, "ended");
  assert.equal(await creative.currentFocus(), null);
});
test("finishing a session twice does not duplicate idea notes", async () => {
  const ideaId = await capture(),
    id = await creative.startFocus({ intention: "Focus", ideaId, seconds: 60 });
  await db.runAsync(
    "UPDATE focus_sessions SET started_at=?,ends_at=? WHERE id=?",
    Date.now() - 61000,
    Date.now() - 1000,
    id,
  );
  await creative.finishFocus(id, "A useful observation");
  await creative.finishFocus(id, "A useful observation");
  assert.equal((await ideas.getIdea(ideaId)).blocks.length, 2);
  assert.equal((await creative.focusHistory())[0].elapsed_seconds, 60);
});
test("removing a project keeps its ideas and clears only membership", async () => {
  const ideaId = await capture(),
    projectId = await creative.saveProject({
      name: "Workshop",
      intention: "Learn",
      color: "#A18AFF",
    });
  await creative.toggleProjectIdea(projectId, ideaId);
  assert.equal((await ideas.searchIdeas("", { projectId })).length, 1);
  await creative.deleteProject(projectId);
  assert.ok(await ideas.getIdea(ideaId));
  assert.equal((await creative.projectMembership(ideaId)).length, 0);
});
test("shortlist and energy filters match persisted fields", async () => {
  const a = await capture(),
    b = await capture("Another idea");
  await ideas.updateIdea(a, { is_starred: 1, energy: "low" });
  assert.deepEqual(
    (await ideas.searchIdeas("", { starred: true, energy: "low" })).map(
      (i) => i.id,
    ),
    [a],
  );
  assert.equal((await ideas.getIdea(b)).energy, "steady");
});
test("trashed ideas disappear from search, graph, detail, and backlinks", async () => {
  const a = await capture(),
    b = await capture("Companion");
  await addIdeaLink(a, b, "related_to");
  await ideas.softDeleteIdea(b);
  assert.equal(await ideas.getIdea(b), null);
  assert.equal((await listConnections(a)).length, 0);
  assert.equal((await creative.listGraph()).edges.length, 0);
  assert.equal((await ideas.searchIdeas("Companion")).length, 0);
  await ideas.restoreIdea(b);
  assert.equal((await listConnections(a)).length, 1);
});
test("trash cancels native reminders and marks them finished", async () => {
  const id = await capture();
  await db.runAsync(
    "INSERT INTO reminders(id,idea_id,scheduled_at,notification_id) VALUES('r',?,?,'notification-1')",
    id,
    Date.now() + 10000,
  );
  await ideas.softDeleteIdea(id);
  assert.deepEqual(canceled, ["notification-1"]);
  assert.ok(
    (await db.getFirstAsync("SELECT completed_at FROM reminders WHERE id='r'"))
      .completed_at,
  );
});
test("permanent deletion cascades tasks and experiments but keeps independent letters", async () => {
  const id = await capture();
  await creative.addAction(id, "Move");
  await creative.createExperiment({
    ideaId: id,
    hypothesis: "H",
    method: "M",
    signal: "S",
  });
  await creative.createCapsule({
    ideaId: id,
    title: "Future",
    body: "Letter",
    unlockAt: Date.now() + 86400000,
  });
  await ideas.permanentlyDeleteIdea(id);
  assert.equal((await creative.listActions(id)).length, 0);
  assert.equal((await creative.listExperiments()).length, 0);
  assert.equal((await creative.listCapsules())[0].idea_id, null);
});
test("saved views and review reflections preserve user content", async () => {
  await creative.saveView("Gentle", "garden", { energy: "low", starred: true });
  await creative.saveReview("Learned", "Released", "Next");
  assert.equal(
    JSON.parse((await creative.savedViews())[0].filters_json).energy,
    "low",
  );
  assert.equal((await creative.reviewHistory())[0].next_week, "Next");
});
test("playground is explicitly labeled and added only once", async () => {
  assert.equal(await creative.seedPlayground(), true);
  assert.equal(await creative.seedPlayground(), false);
  const all = await ideas.listIdeas();
  assert.equal(all.length, 6);
  assert.ok(all.every((i) => i.title.startsWith("[Playground]")));
  assert.equal((await creative.listGraph()).edges.length, 4);
});
test("export contains Studio tables, readable tasks, and attachment diagnostics", async () => {
  const id = await ideas.createIdeaFromCapture({
    text: "Export me",
    attachment: { type: "file", uri: "file:///missing.txt" },
  });
  await creative.addAction(id, "A portable task");
  await creative.createCapsule({
    title: "Letter",
    body: "Remember this",
    unlockAt: Date.now() + 86400000,
  });
  const uri = await exportAllData();
  const zip = unzipSync(Buffer.from(files.get(uri), "base64"));
  const snapshot = JSON.parse(strFromU8(zip["ideas-export.json"]));
  assert.equal(snapshot.schema, 2);
  for (const table of [
    "projects",
    "action_items",
    "experiments",
    "time_capsules",
    "focus_sessions",
    "review_entries",
    "saved_views",
    "drafts",
  ])
    assert.ok(Array.isArray(snapshot.data[table]));
  assert.equal(
    JSON.parse(strFromU8(zip["attachment-manifest.json"])).missing.length,
    1,
  );
  assert.match(await singleIdeaMarkdown(id), /A portable task/);
});

test("capture clears its recovered draft in the same transaction", async () => {
  await ideas.saveDraft("capture-test", "A preserved draft");
  const id = await ideas.createIdeaFromCapture({
    text: "A preserved draft",
    draftId: "capture-test",
  });
  assert.equal(await ideas.getDraft("capture-test"), null);
  assert.equal(
    (await ideas.getIdea(id)).blocks[0].body_text,
    "A preserved draft",
  );
});
test("a capture storage failure leaves both the original draft and the vault intact", async () => {
  await ideas.saveDraft("capture-failure", "Keep me");
  await db.execAsync(
    "CREATE TEMP TRIGGER simulate_capture_failure BEFORE INSERT ON idea_blocks BEGIN SELECT RAISE(ABORT,'Simulated storage failure'); END;",
  );
  try {
    await assert.rejects(() =>
      ideas.createIdeaFromCapture({
        text: "Keep me",
        draftId: "capture-failure",
      }),
    );
  } finally {
    await db.execAsync("DROP TRIGGER simulate_capture_failure;");
  }
  assert.equal((await ideas.getDraft("capture-failure")).body_text, "Keep me");
  assert.equal((await ideas.listIdeas()).length, 0);
});

test("browser search works when the database has a plain index instead of FTS5", async () => {
  await db.execAsync(
    "DROP TABLE idea_fts; CREATE TABLE idea_fts (idea_id TEXT PRIMARY KEY,title TEXT,summary TEXT,body TEXT);",
  );
  const id = await capture("A literal garden_sensor in हिन्दी");
  await ideas.updateIdea(id, { energy: "low" });
  assert.equal(
    (await ideas.searchIdeas("garden_sensor", { energy: "low" }))[0].id,
    id,
  );
  assert.equal((await ideas.searchIdeas("हिन्दी")).length, 1);
  assert.equal((await ideas.searchIdeas("missing")).length, 0);
  assert.equal((await ideas.searchIdeas('" OR ()')).length, 1);
});

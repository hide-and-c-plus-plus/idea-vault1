export const colors = {
  bg: "#0E1016",
  surface: "#171A23",
  surfaceRaised: "#1E2230",
  surfaceHover: "#1E252E",
  border: "#303648",
  textPrimary: "#F3F6F9",
  textSecondary: "#9CA8B5",
  textMuted: "#8E99AB",
  accent: "#A18AFF",
  accentSoft: "#282342",
  success: "#42C98E",
  warning: "#E9B44C",
  danger: "#F06A73",
} as const;

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
} as const;
export const radius = { sm: 8, md: 12, lg: 16, pill: 999 } as const;

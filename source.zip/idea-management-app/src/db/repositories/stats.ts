import { getDb } from "../database";

export async function getReviewStats() {
  const db = await getDb();
  const row = await db.getFirstAsync<{
    inbox: number;
    promising: number;
    active: number;
    dormant: number;
  }>(
    `
    SELECT
      SUM(CASE WHEN inbox_state='unprocessed' AND deleted_at IS NULL THEN 1 ELSE 0 END) AS inbox,
      SUM(CASE WHEN stage='promising' AND deleted_at IS NULL THEN 1 ELSE 0 END) AS promising,
      SUM(CASE WHEN stage='active' AND deleted_at IS NULL THEN 1 ELSE 0 END) AS active,
      SUM(CASE WHEN last_touched_at < ? AND deleted_at IS NULL AND stage NOT IN ('done','dropped','archived') THEN 1 ELSE 0 END) AS dormant
    FROM ideas`,
    Date.now() - 30 * 86_400_000,
  );
  return row ?? { inbox: 0, promising: 0, active: 0, dormant: 0 };
}

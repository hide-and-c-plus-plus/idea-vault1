import { getDb } from "../database";
import { writeDb } from "../write";
import { createId } from "@/utils/id";
import type { LinkType } from "@/domain/types";
import { logEvent } from "./ideas";
export interface IdeaConnection {
  id: string;
  other_id: string;
  other_title: string | null;
  link_type: LinkType;
  direction: "outgoing" | "incoming";
  note: string | null;
}
export function addIdeaLink(
  sourceId: string,
  targetId: string,
  linkType: LinkType,
  note: string | null = null,
) {
  if (sourceId === targetId) throw new Error("An idea cannot link to itself.");
  return writeDb(async (db) => {
    for (const id of [sourceId, targetId])
      if (
        !(await db.getFirstAsync(
          "SELECT id FROM ideas WHERE id=? AND deleted_at IS NULL",
          id,
        ))
      )
        throw new Error("This idea is unavailable.");
    const exists = await db.getFirstAsync<{ id: string }>(
      "SELECT id FROM idea_links WHERE source_idea_id=? AND target_idea_id=? AND link_type=?",
      sourceId,
      targetId,
      linkType,
    );
    if (exists) return exists.id;
    const id = createId("link");
    await db.runAsync(
      "INSERT INTO idea_links(id,source_idea_id,target_idea_id,link_type,note,created_at) VALUES(?,?,?,?,?,?)",
      id,
      sourceId,
      targetId,
      linkType,
      note,
      Date.now(),
    );
    await logEvent(db, sourceId, "link_added", { targetId, linkType });
    return id;
  });
}
export async function listConnections(id: string) {
  return (await getDb()).getAllAsync<IdeaConnection>(
    `SELECT l.id,l.target_idea_id AS other_id,t.title AS other_title,l.link_type,'outgoing' AS direction,l.note FROM idea_links l JOIN ideas t ON t.id=l.target_idea_id WHERE l.source_idea_id=? AND t.deleted_at IS NULL UNION ALL SELECT l.id,l.source_idea_id AS other_id,s.title AS other_title,l.link_type,'incoming' AS direction,l.note FROM idea_links l JOIN ideas s ON s.id=l.source_idea_id WHERE l.target_idea_id=? AND s.deleted_at IS NULL ORDER BY other_title`,
    id,
    id,
  );
}
export const removeIdeaLink = (id: string) =>
  writeDb(async (db) => {
    await db.runAsync("DELETE FROM idea_links WHERE id=?", id);
  });

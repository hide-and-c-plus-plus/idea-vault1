import * as SQLite from "expo-sqlite";

let databasePromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb() {
  if (!databasePromise) {
    databasePromise = SQLite.openDatabaseAsync("idea-vault.db")
      .then(async (db) => {
        await db.execAsync(
          "PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;",
        );
        return db;
      })
      .catch((error) => {
        databasePromise = null;
        throw error;
      });
  }
  return databasePromise;
}

export async function supportsFts5(
  db: SQLite.SQLiteDatabase,
): Promise<boolean> {
  const existing = await db.getFirstAsync<{ sql: string }>(
    "SELECT sql FROM sqlite_master WHERE name='idea_fts'",
  );
  if (existing) return /USING\s+fts5/i.test(existing.sql);
  try {
    await db.execAsync(
      "CREATE VIRTUAL TABLE temp.idea_fts_probe USING fts5(body); DROP TABLE temp.idea_fts_probe;",
    );
    return true;
  } catch (error) {
    if (/no such module.*fts5/i.test(String(error))) return false;
    throw error;
  }
}

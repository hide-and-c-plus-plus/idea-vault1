import { useCallback, useEffect, useRef, useState } from "react";
import { Alert } from "react-native";
import { useDataChange } from "@/state/DataChangeContext";
import { useFeedback } from "@/state/FeedbackContext";
import { clearDraft, getDraft, saveDraft } from "@/db/repositories/ideas";

export function useLoad<T>(loader: () => Promise<T>, deps: unknown[] = []) {
  const { epoch } = useDataChange();
  const [data, setData] = useState<T | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true),
    [retry, setRetry] = useState(0);
  const ref = useRef(loader);
  ref.current = loader;
  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError("");
    ref
      .current()
      .then((value) => {
        if (alive) setData(value);
      })
      .catch((e) => {
        if (alive) setError(e instanceof Error ? e.message : String(e));
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [epoch, retry, ...deps]);
  return { data, error, loading, reload: () => setRetry((x) => x + 1) };
}
export function useAction() {
  const [busy, setBusy] = useState(false);
  const locked = useRef(false);
  const { bump } = useDataChange();
  const notify = useFeedback();
  const run = async <T>(
    work: () => Promise<T>,
    message?: string,
  ): Promise<T | undefined> => {
    if (locked.current) return;
    locked.current = true;
    setBusy(true);
    try {
      const value = await work();
      bump();
      if (message) notify(message);
      return value;
    } catch (e) {
      const text = e instanceof Error ? e.message : String(e);
      notify(text, true);
      Alert.alert("Could not complete that", text);
      return undefined;
    } finally {
      locked.current = false;
      setBusy(false);
    }
  };
  return { run, busy };
}
export function useDraftForm<T extends object>(key: string, initial: T) {
  const [value, setValue] = useState<T>(initial),
    [ready, setReady] = useState(false);
  const latest = useRef(value),
    loaded = useRef(false),
    paused = useRef(false);
  latest.current = value;
  const initialRef = useRef(initial);
  initialRef.current = initial;
  useEffect(() => {
    let alive = true;
    loaded.current = false;
    paused.current = false;
    setReady(false);
    getDraft(key)
      .then((d) => {
        if (!alive) return;
        let restored = initialRef.current;
        try {
          if (d?.metadata_json)
            restored = { ...restored, ...JSON.parse(d.metadata_json) };
        } catch {}
        setValue(restored);
        latest.current = restored;
        loaded.current = true;
        setReady(true);
      })
      .catch(() => {
        if (alive) {
          loaded.current = true;
          setReady(true);
        }
      });
    return () => {
      alive = false;
      if (loaded.current && !paused.current)
        void saveDraft(
          key,
          "",
          "creative",
          null,
          JSON.stringify(latest.current),
        ).catch(() => {});
    };
  }, [key]);
  useEffect(() => {
    if (!ready || paused.current) return;
    const timer = setTimeout(() => {
      if (!paused.current)
        void saveDraft(key, "", "creative", null, JSON.stringify(value)).catch(
          () => {},
        );
    }, 450);
    return () => clearTimeout(timer);
  }, [value, ready, key]);
  const clear = useCallback(async () => {
    paused.current = true;
    await clearDraft(key);
  }, [key]);
  const resume = () => {
    paused.current = false;
  };
  return { value, setValue, ready, clear, resume };
}

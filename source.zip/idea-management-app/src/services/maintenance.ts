import { getDb } from "@/db/database";
import { permanentlyDeleteIdea } from "@/db/repositories/ideas";
export async function purgeExpiredTrash() {
  const rows = await (
    await getDb()
  ).getAllAsync<{ id: string }>(
    "SELECT id FROM ideas WHERE deleted_at IS NOT NULL AND deleted_at<?",
    Date.now() - 30 * 86400000,
  );
  for (const row of rows) await permanentlyDeleteIdea(row.id);
  return rows.length;
}

import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import { createIdeaFromCapture } from "@/db/repositories/ideas";
export async function importTextIdea() {
  const result = await DocumentPicker.getDocumentAsync({
    type: ["text/plain", "text/markdown", "text/x-markdown"],
    copyToCacheDirectory: true,
    multiple: false,
  });
  if (result.canceled) return null;
  const asset = result.assets[0];
  if (!asset) return null;
  if (asset.size && asset.size > 1024 * 1024)
    throw new Error("Choose a text note smaller than 1 MB.");
  const text = await FileSystem.readAsStringAsync(asset.uri);
  if (text.length > 1024 * 1024)
    throw new Error("This text note is too large to import.");
  if (!text.trim()) throw new Error("The selected note is empty.");
  if (text.includes("\u0000"))
    throw new Error("Choose a plain text or Markdown file.");
  return createIdeaFromCapture({
    title: asset.name.replace(/\.(md|txt|markdown)$/i, ""),
    text,
    sourceType: "import",
  });
}

import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import { strToU8, zipSync } from "fflate";
import { writeDb } from "@/db/write";
import { getDb } from "@/db/database";
import { getIdea } from "@/db/repositories/ideas";
import { listActions, listExperiments } from "@/db/repositories/creative";
import type { Idea } from "@/domain/types";

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(
      ...bytes.subarray(i, Math.min(i + chunk, bytes.length)),
    );
  }
  return globalThis.btoa(binary);
}

function base64ToBytes(base64: string) {
  const binary = globalThis.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function safeName(value: string) {
  return (
    value
      .replace(/[\\/:*?"<>|]+/g, "-")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80) || "Untitled idea"
  );
}

function ideaMarkdown(idea: any, blocks: any[], tags: any[]) {
  const lines = [
    `# ${idea.title || "Untitled idea"}`,
    "",
    `- Stage: ${idea.stage}`,
    `- Created: ${new Date(idea.created_at).toISOString()}`,
    `- Updated: ${new Date(idea.updated_at).toISOString()}`,
    `- Tags: ${tags.map((x) => x.name).join(", ") || "—"}`,
    "",
  ];
  if (idea.summary) lines.push("## Summary", "", idea.summary, "");
  for (const block of blocks) {
    if (block.type === "text" && block.body_text) {
      lines.push(
        block.is_original ? "## Original capture" : "## Thought",
        "",
        block.body_text,
        "",
      );
    } else if (block.attachment_id) {
      lines.push(`- ${block.type} attachment: ${block.attachment_id}`);
    }
  }
  if (
    idea.problem ||
    idea.audience ||
    idea.next_experiment ||
    idea.next_action ||
    idea.done_definition
  ) {
    lines.push("", "## Development", "");
    if (idea.problem)
      lines.push(`**Problem / opportunity:** ${idea.problem}`, "");
    if (idea.audience) lines.push(`**Who benefits:** ${idea.audience}`, "");
    if (idea.next_experiment)
      lines.push(`**Smallest test:** ${idea.next_experiment}`, "");
    if (idea.next_action)
      lines.push(`**Next action:** ${idea.next_action}`, "");
    if (idea.done_definition)
      lines.push(`**Done looks like:** ${idea.done_definition}`, "");
  }
  if (idea.why_now) lines.push("## Why now", "", idea.why_now, "");
  if (idea.risks) lines.push("## Risks", "", idea.risks, "");
  return lines.join("\n");
}

export async function exportAllData() {
  const db = await getDb();
  const tables = [
    "ideas",
    "idea_blocks",
    "idea_events",
    "categories",
    "tags",
    "idea_tags",
    "idea_links",
    "attachments",
    "transcripts",
    "reminders",
    "resurfacing_events",
    "feedback_notes",
    "app_settings",
    "drafts",
    "projects",
    "project_ideas",
    "action_items",
    "experiments",
    "time_capsules",
    "focus_sessions",
    "review_entries",
    "saved_views",
  ];
  const data: Record<string, unknown[]> = {};
  await writeDb(async (tx) => {
    for (const table of tables)
      data[table] = await tx.getAllAsync(`SELECT * FROM ${table}`);
  });
  const ideas = data.ideas as Idea[];
  const blocks = data.idea_blocks as any[];
  const tags = data.tags as any[];
  const ideaTags = data.idea_tags as any[];
  const attachments = data.attachments as any[];

  const archive: Record<string, Uint8Array> = {};
  archive["ideas-export.json"] = strToU8(
    JSON.stringify(
      { exportedAt: new Date().toISOString(), schema: 2, data },
      null,
      2,
    ),
  );

  for (const idea of ideas) {
    const ideaBlocks = blocks
      .filter((b) => b.idea_id === idea.id)
      .sort((a, b) => a.position - b.position || a.created_at - b.created_at);
    const tagIds = ideaTags
      .filter((it) => it.idea_id === idea.id)
      .map((it) => it.tag_id);
    const ideaTagRows = tags.filter((t) => tagIds.includes(t.id));
    archive[
      `markdown/${safeName(idea.title || idea.id)}-${idea.id.slice(-6)}.md`
    ] = strToU8(
      ideaMarkdown(idea, ideaBlocks, ideaTagRows) +
        workbenchMarkdown(
          idea.id,
          data.action_items as any[],
          data.experiments as any[],
        ),
    );
  }

  const missingAttachments: string[] = [];
  const attachmentPaths: Record<string, string> = {};
  for (const attachment of attachments) {
    try {
      const info = await FileSystem.getInfoAsync(attachment.local_uri);
      if (!info.exists) {
        missingAttachments.push(attachment.id);
        continue;
      }
      const base64 = await FileSystem.readAsStringAsync(attachment.local_uri, {
        encoding: FileSystem.EncodingType.Base64,
      });
      const ext = (attachment.local_uri.split(".").pop() || "bin").replace(
        /[^a-zA-Z0-9]/g,
        "",
      );
      const path = `attachments/${attachment.id}.${ext || "bin"}`;
      archive[path] = base64ToBytes(base64);
      attachmentPaths[attachment.id] = path;
    } catch {
      missingAttachments.push(attachment.id);
    }
  }

  archive["attachment-manifest.json"] = strToU8(
    JSON.stringify(
      { files: attachmentPaths, missing: missingAttachments },
      null,
      2,
    ),
  );
  archive["README.txt"] = strToU8(
    "Idea Vault / Creative Studio export\n\nideas-export.json contains all persistent tables, including Studio work. Markdown files contain readable idea briefs, tasks, and experiments. attachment-manifest.json maps attachment IDs to files and lists missing files. Device-local URIs in JSON are historical references, not portable paths. Draft media may still reference the original device. This is an archival export; the app imports individual text or Markdown notes, not a full archive restore. Time-capsule letters are included in plain text in JSON.",
  );
  const zip = zipSync(archive, { level: 6 });
  const uri = `${FileSystem.cacheDirectory}idea-vault-export-${new Date().toISOString().slice(0, 10)}.zip`;
  await FileSystem.writeAsStringAsync(uri, bytesToBase64(zip), {
    encoding: FileSystem.EncodingType.Base64,
  });
  if (await Sharing.isAvailableAsync())
    await Sharing.shareAsync(uri, {
      mimeType: "application/zip",
      dialogTitle: "Export Idea Vault",
    });
  return uri;
}

function workbenchMarkdown(id: string, actions: any[], experiments: any[]) {
  const lines: string[] = [];
  const tasks = actions.filter((a) => a.idea_id === id),
    tests = experiments.filter((e) => e.idea_id === id);
  if (tasks.length)
    lines.push(
      "",
      "## Next moves",
      "",
      ...tasks.map((a) => `- [${a.done_at ? "x" : " "}] ${a.body}`),
      "",
    );
  for (const e of tests)
    lines.push(
      "",
      "## Experiment",
      "",
      `**Prediction:** ${e.hypothesis}`,
      "",
      `**Test:** ${e.method}`,
      "",
      `**Success signal:** ${e.success_signal}`,
      "",
      `**Outcome:** ${e.verdict}`,
      "",
      `**Observed:** ${e.result || "Not recorded"}`,
      "",
    );
  return lines.join("\n");
}
export async function singleIdeaMarkdown(id: string) {
  const idea = await getIdea(id);
  if (!idea) throw new Error("Idea not found.");
  return (
    ideaMarkdown(idea, idea.blocks, idea.tags) +
    workbenchMarkdown(id, await listActions(id), await listExperiments(id))
  );
}

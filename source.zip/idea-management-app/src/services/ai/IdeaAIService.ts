export interface Suggestion<T> {
  value: T;
  rationale?: string;
  provider: string;
}
export interface IdeaContext {
  id?: string;
  title?: string | null;
  text: string;
  tags?: string[];
}
export interface TaxonomySuggestion {
  category?: string;
  tags: string[];
}
export interface RelatedIdeaSuggestion {
  ideaId: string;
  score: number;
  reason: string;
}
export interface SplitSuggestion {
  title: string;
  text: string;
}
export interface DevelopmentSuggestion {
  questions: string[];
  nextExperiment?: string;
}

export interface IdeaAIService {
  suggestTitle(input: IdeaContext): Promise<Suggestion<string> | null>;
  suggestTaxonomy(input: IdeaContext): Promise<TaxonomySuggestion | null>;
  detectRelated(input: IdeaContext): Promise<RelatedIdeaSuggestion[]>;
  proposeSplit(input: IdeaContext): Promise<SplitSuggestion[]>;
  develop(input: IdeaContext): Promise<DevelopmentSuggestion | null>;
}

export class NoopAIService implements IdeaAIService {
  suggestTitle() {
    return Promise.resolve(null);
  }
  suggestTaxonomy() {
    return Promise.resolve(null);
  }
  detectRelated() {
    return Promise.resolve([]);
  }
  proposeSplit() {
    return Promise.resolve([]);
  }
  develop() {
    return Promise.resolve(null);
  }
}

export const ideaAI: IdeaAIService = new NoopAIService();

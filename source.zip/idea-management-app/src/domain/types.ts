export type IdeaStage =
  | "spark"
  | "exploring"
  | "promising"
  | "active"
  | "done"
  | "parked"
  | "dropped"
  | "archived";
export type InboxState = "unprocessed" | "processed";
export type Horizon =
  "now" | "soon" | "someday" | "evergreen" | "time-sensitive";
export type BlockType =
  | "text"
  | "audio"
  | "audio_transcript"
  | "image"
  | "link"
  | "checklist"
  | "file";
export type LinkType =
  | "related_to"
  | "builds_on"
  | "contradicts"
  | "duplicate_of"
  | "combines_with"
  | "inspired_by"
  | "child_of"
  | "parent_of";

export interface Idea {
  id: string;
  title: string | null;
  summary: string | null;
  stage: IdeaStage;
  inbox_state: InboxState;
  primary_category_id: string | null;
  category_name?: string | null;
  horizon: Horizon | null;
  potential: number | null;
  effort: number | null;
  next_action: string | null;
  done_definition: string | null;
  problem: string | null;
  audience: string | null;
  why_now: string | null;
  next_experiment: string | null;
  risks: string | null;
  created_at: number;
  updated_at: number;
  last_touched_at: number;
  archived_at: number | null;
  dropped_at: number | null;
  deleted_at: number | null;
  source_type: string;
  original_capture_id: string;
  is_starred: number;
  energy: "low" | "steady" | "deep";
  snippet?: string | null;
}

export interface IdeaBlock {
  id: string;
  idea_id: string;
  type: BlockType;
  body_text: string | null;
  attachment_id: string | null;
  derived_from_block_id: string | null;
  position: number;
  created_at: number;
  updated_at: number;
  is_original: number;
}

export interface Category {
  id: string;
  name: string;
  parent_id: string | null;
  color_token: string | null;
  sort_order: number;
  archived_at: number | null;
}
export interface Tag {
  id: string;
  name: string;
  normalized_name: string;
  color_token: string | null;
  created_at: number;
}
export interface Attachment {
  id: string;
  idea_id: string;
  block_id: string | null;
  kind: string;
  local_uri: string;
  mime_type: string | null;
  byte_size: number | null;
  duration_ms: number | null;
  sha256: string | null;
  created_at: number;
}
export interface Reminder {
  id: string;
  idea_id: string;
  scheduled_at: number;
  kind: string;
  snoozed_until: number | null;
  notification_id: string | null;
  completed_at: number | null;
}

export interface IdeaDetail extends Idea {
  blocks: IdeaBlock[];
  tags: Tag[];
  attachments: Attachment[];
}

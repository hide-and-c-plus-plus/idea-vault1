// Pure, deterministic helpers: tested without a simulator or a network service.
export function localDayKey(date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
export function dayKeys(count: number, now = new Date()): string[] {
  return Array.from({ length: count }, (_, index) => {
    const d = new Date(now);
    d.setDate(d.getDate() - count + index + 1);
    return localDayKey(d);
  });
}
export function dailyIndex(length: number, now = new Date()): number {
  if (length < 1) return 0;
  // A calendar-day ordinal avoids daylight-saving changes to the prompt.
  return (
    Math.floor(
      Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()) / 86_400_000,
    ) % length
  );
}
export function shuffle<T>(items: readonly T[], random = Math.random): T[] {
  const result = [...items];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [result[i], result[j]] = [result[j]!, result[i]!];
  }
  return result;
}
const STOP_WORDS = new Set(
  "a an and are as at be but by can could for from how i in into is it its me my of on or our that the their them there these they this to was we were what when where which who why will with would you your idea app make use".split(
    " ",
  ),
);
export function meaningfulWords(value: string): Set<string> {
  return new Set(
    (value.toLocaleLowerCase().match(/[\p{L}\p{M}\p{N}]+/gu) ?? []).filter(
      (w) => w.length > 2 && !STOP_WORDS.has(w),
    ),
  );
}
export function commonWords(a: string, b: string): string[] {
  const right = meaningfulWords(b);
  return [...meaningfulWords(a)].filter((w) => right.has(w));
}
export function relatedIdeas<
  T extends {
    id: string;
    title: string | null;
    summary?: string | null;
    snippet?: string | null;
  },
>(source: T, ideas: T[]): { idea: T; words: string[] }[] {
  const text = (i: T) =>
    [i.title, i.summary, i.snippet].filter(Boolean).join(" ");
  return ideas
    .filter((i) => i.id !== source.id)
    .map((idea) => ({ idea, words: commonWords(text(source), text(idea)) }))
    .filter((x) => x.words.length > 0)
    .sort(
      (a, b) =>
        b.words.length - a.words.length || a.idea.id.localeCompare(b.idea.id),
    )
    .slice(0, 5);
}
export function focusProgress(
  session: { started_at: number; ends_at: number; planned_seconds: number },
  now: number,
) {
  const elapsed = Math.max(
    0,
    Math.min(
      session.planned_seconds,
      Math.floor((now - session.started_at) / 1000),
    ),
  );
  const remaining = Math.max(
    0,
    Math.min(
      session.planned_seconds,
      Math.ceil((session.ends_at - now) / 1000),
    ),
  );
  return {
    elapsed,
    remaining,
    fraction:
      session.planned_seconds > 0
        ? Math.min(1, elapsed / session.planned_seconds)
        : 1,
  };
}
export function formatClock(seconds: number) {
  const safe = Math.max(0, Math.floor(seconds));
  return `${String(Math.floor(safe / 60)).padStart(2, "0")}:${String(safe % 60).padStart(2, "0")}`;
}
export function ringPoints(count: number, width: number, height: number) {
  if (count === 0) return [];
  if (count === 1) return [{ x: width / 2, y: height / 2 }];
  const rx = Math.max(0, width / 2 - 52),
    ry = Math.max(0, height / 2 - 54);
  return Array.from({ length: count }, (_, i) => {
    const angle = -Math.PI / 2 + (2 * Math.PI * i) / count;
    return {
      x: width / 2 + rx * Math.cos(angle),
      y: height / 2 + ry * Math.sin(angle),
    };
  });
}
export function safeFtsQuery(query: string) {
  const tokens = query.match(/[\p{L}\p{M}\p{N}_]+/gu)?.slice(0, 8) ?? [];
  return tokens.map((x) => `"${x}"*`).join(" AND ");
}
export function cleanText(value: string, label: string, max = 20000) {
  const text = value.trim();
  if (!text) throw new Error(`${label} cannot be empty.`);
  if (text.length > max)
    throw new Error(`${label} is too long (maximum ${max} characters).`);
  return text;
}
export function activityStreak(activeDays: string[], now = new Date()): number {
  const days = new Set(activeDays);
  const date = new Date(now);
  // Yesterday remains a live streak until today is over.
  if (!days.has(localDayKey(date))) date.setDate(date.getDate() - 1);
  let count = 0;
  while (days.has(localDayKey(date))) {
    count++;
    date.setDate(date.getDate() - 1);
  }
  return count;
}

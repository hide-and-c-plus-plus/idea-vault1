export interface PromptCard {
  id: string;
  title: string;
  prompt: string;
  hint: string;
}
export const TEMPLATES = [
  { id: "blank", title: "Free thought", glyph: "✦", body: "" },
  {
    id: "problem",
    title: "Friction log",
    glyph: "↯",
    body: "I noticed this friction:\n\nWho experiences it:\n\nThe workaround people use:\n\nWhat could be easier:\n",
  },
  {
    id: "product",
    title: "Product seed",
    glyph: "◈",
    body: "For someone who…\n\nI could build…\n\nUnlike the current workaround…\n\nThe smallest useful version…\n",
  },
  {
    id: "research",
    title: "Research question",
    glyph: "⌕",
    body: "The question:\n\nWhat I already know:\n\nWhat would change my mind:\n\nA source or experiment to start with:\n",
  },
  {
    id: "story",
    title: "Story seed",
    glyph: "❝",
    body: "Someone wants…\n\nBut…\n\nThe surprising turn…\n\nAn image or line I want to keep:\n",
  },
  {
    id: "learning",
    title: "Learning lab",
    glyph: "◎",
    body: "I want to understand…\n\nMy current mental model:\n\nA tiny example I can build:\n\nHow I will explain it without notes:\n",
  },
  {
    id: "observation",
    title: "Field note",
    glyph: "◉",
    body: "Where I was:\n\nWhat actually happened:\n\nMy interpretation (not a fact):\n\nThe question it raises:\n",
  },
  {
    id: "wild",
    title: "Impossible idea",
    glyph: "✧",
    body: "If this impossible thing were possible…\n\nThe part that excites me:\n\nOne small piece that might work today:\n",
  },
  {
    id: "personal",
    title: "Life experiment",
    glyph: "❋",
    body: "A little thing I would like to change:\n\nA reversible experiment:\n\nWhat I will notice:\n\nWhen I will reflect:\n",
  },
  {
    id: "letter",
    title: "Future-self letter",
    glyph: "↗",
    body: "Dear future me,\n\nRight now I am wondering…\n\nPlease remember…\n\nI hope you tried…\n",
  },
  {
    id: "analogy",
    title: "Borrow a pattern",
    glyph: "⇄",
    body: "This works beautifully in…\n\nThe underlying principle:\n\nWhat if I used it in…\n\nWhere the analogy breaks:\n",
  },
  {
    id: "decision",
    title: "Decision journal",
    glyph: "⑂",
    body: "The decision:\n\nThe options:\n\nWhat I know / what I assume:\n\nMy choice and why:\n\nWhat would make me revisit it:\n",
  },
] as const;

export const DAILY_PROMPTS: PromptCard[] = [
  {
    id: "workaround",
    title: "Follow the workaround",
    prompt:
      "What awkward workaround did you use today? Design the thing that would make it unnecessary.",
    hint: "Start with a real moment, however small.",
  },
  {
    id: "invisible",
    title: "Make the invisible visible",
    prompt:
      "What useful information is hidden in an everyday activity? Give it a simple, visible form.",
    hint: "Think of waiting, learning, habits, or wasted effort.",
  },
  {
    id: "reverse",
    title: "Turn it inside out",
    prompt: "Pick a familiar service. What if the customer became the creator?",
    hint: "Keep the benefit; reverse the roles.",
  },
  {
    id: "tiny",
    title: "One tiny delight",
    prompt:
      "Invent something that makes a boring thirty seconds unexpectedly pleasant.",
    hint: "A queue, an elevator ride, or a loading screen.",
  },
  {
    id: "borrow",
    title: "Steal a principle",
    prompt:
      "Borrow one principle from a library, garden, or kitchen and apply it to a digital tool.",
    hint: "Borrow the mechanism, not the appearance.",
  },
  {
    id: "delete",
    title: "Design by subtraction",
    prompt:
      "Take something you use often. Remove its most obvious feature. How could it still be useful?",
    hint: "The missing piece may reveal the real purpose.",
  },
  {
    id: "quiet",
    title: "Build for quiet",
    prompt:
      "What would a useful app look like if it never competed for your attention?",
    hint: "No streak pressure, no infinite feed. Still valuable.",
  },
  {
    id: "access",
    title: "Start at the edge",
    prompt:
      "Design for someone with an older phone, little data, and five spare minutes.",
    hint: "Constraints can expose a better core experience.",
  },
  {
    id: "future",
    title: "A postcard from later",
    prompt:
      "Imagine a problem you solved a year from now. What was the first surprisingly small step?",
    hint: "Write that step as something you could try this week.",
  },
  {
    id: "pair",
    title: "An unlikely alliance",
    prompt:
      "Combine your most practical interest with your strangest hobby. What could only you make?",
    hint: "Keep one concrete ingredient from each.",
  },
  {
    id: "repair",
    title: "Repair, do not replace",
    prompt:
      "What existing thing could become wonderful with one carefully chosen change?",
    hint: "Look at an unfinished project or an old routine.",
  },
  {
    id: "teach",
    title: "Teach it sideways",
    prompt:
      "Explain a difficult idea using a game, a recipe, or a physical object.",
    hint: "What does the metaphor reveal? What does it hide?",
  },
  {
    id: "ritual",
    title: "A better ritual",
    prompt:
      "Turn an annoying repeated task into a satisfying beginning, middle, and end.",
    hint: "Consider the feeling before and after, not only speed.",
  },
  {
    id: "anti",
    title: "The anti-solution",
    prompt:
      "Design the worst possible solution to a problem. Reverse its most interesting failure.",
    hint: "Be playfully specific before you reverse it.",
  },
  {
    id: "evidence",
    title: "What would surprise you?",
    prompt:
      "Choose an idea you believe in. What observation would genuinely surprise you?",
    hint: "Make that observation the seed of a test.",
  },
  {
    id: "local",
    title: "One street, one problem",
    prompt:
      "Invent something useful for only your classroom, street, hostel, or family.",
    hint: "A tiny audience can reveal a very real need.",
  },
  {
    id: "slow",
    title: "Let it take time",
    prompt:
      "What gets better when it grows slowly? Design a product around that rhythm.",
    hint: "Trust, craft, understanding, and relationships are clues.",
  },
  {
    id: "physical",
    title: "Bring it off-screen",
    prompt:
      "Turn a digital habit into a physical object or shared real-world activity.",
    hint: "Keep the value. Change the medium.",
  },
  {
    id: "permission",
    title: "Remove a permission slip",
    prompt:
      "What do people wait for permission to try? Design a safe first step they can take themselves.",
    hint: "Small, reversible, and within their control.",
  },
  {
    id: "forgotten",
    title: "Visit an old spark",
    prompt:
      "Find an idea you parked. Which part is still alive, even if the original plan is not?",
    hint: "You can rescue a fragment without reviving the whole project.",
  },
  {
    id: "human",
    title: "Keep the human part",
    prompt:
      "What would you deliberately refuse to automate, and what could you build around it?",
    hint: "Consider care, choice, taste, and conversation.",
  },
];

export const REMIX_CARDS: PromptCard[] = [
  {
    id: "substitute",
    title: "Substitute",
    prompt:
      "Replace a material, audience, channel, or step. What new possibility appears?",
    hint: "What could do the same job in a different way?",
  },
  {
    id: "combine",
    title: "Combine",
    prompt:
      "Add an apparently unrelated ritual, object, or service. What becomes possible together?",
    hint: "Think beyond combining two feature lists.",
  },
  {
    id: "adapt",
    title: "Adapt",
    prompt:
      "Where has a similar problem already been solved? Borrow its mechanism.",
    hint: "Try nature, sports, music, libraries, or street markets.",
  },
  {
    id: "modify",
    title: "Magnify / shrink",
    prompt:
      "Make one ingredient much smaller, slower, bigger, or more personal.",
    hint: "Change the scale and watch the assumptions change.",
  },
  {
    id: "reuse",
    title: "Another use",
    prompt: "Who else would value this? What new job could this idea do?",
    hint: "Start with an unexpected audience.",
  },
  {
    id: "eliminate",
    title: "Eliminate",
    prompt:
      "Remove the most expensive or complicated part. What remains valuable?",
    hint: "Keep removing until you find the irreducible benefit.",
  },
  {
    id: "reverse",
    title: "Reverse",
    prompt: "Swap the order, roles, default, or direction. What changes?",
    hint: "What if the last step happened first?",
  },
];

export const LENSES: PromptCard[] = [
  {
    id: "dreamer",
    title: "The dreamer",
    prompt: "If this worked beautifully, what would become possible?",
    hint: "Suspend feasibility for a moment. Name the promise.",
  },
  {
    id: "user",
    title: "The first user",
    prompt: "What am I trying to do, and why would I change what I do today?",
    hint: "Speak as one specific person in one real situation.",
  },
  {
    id: "skeptic",
    title: "The kind skeptic",
    prompt: "Which assumption could quietly break this idea?",
    hint: "Challenge the assumption, not yourself.",
  },
  {
    id: "builder",
    title: "The maker",
    prompt: "What can I make in one afternoon that teaches me something?",
    hint: "A sketch, a conversation, or a paper prototype counts.",
  },
  {
    id: "steward",
    title: "The caretaker",
    prompt:
      "Who might be excluded or inconvenienced, and how could I change that?",
    hint: "Look at access, privacy, upkeep, and unintended effects.",
  },
  {
    id: "editor",
    title: "The editor",
    prompt: "What is the one sentence at the heart of this idea?",
    hint: "Say who it helps and what becomes better.",
  },
  {
    id: "future",
    title: "Future you",
    prompt:
      "Imagine you stopped working on this. What did you learn, and what was still worth it?",
    hint: "Separate a worthwhile experiment from a guaranteed outcome.",
  },
];

export const CONSTRAINTS = [
  "It must work without the internet.",
  "The first version can use only paper.",
  "It has to help exactly one person first.",
  "No screen is allowed.",
  "Remove accounts, feeds, and notifications.",
  "Explain it without technical words.",
  "Make it useful in under one minute.",
  "Borrow a mechanism from a garden.",
  "The user creates half the value.",
  "It must be repairable by its user.",
  "Make the smallest version you could finish today.",
  "It must work one-handed.",
  "It should get quieter as it becomes more useful.",
  "Use something you already own.",
  "It must teach the user something reusable.",
  "The first interaction happens in person.",
  "Make the opposite of the obvious solution.",
  "The output is a physical object.",
  "It must be enjoyable without competition.",
  "Build for an older phone.",
  "It only exists for one afternoon.",
  "It must make someone feel welcome.",
  "Trade speed for care.",
  "Make its limitations visible.",
];

export const COLLISION_BRIDGES = [
  "Use the mechanism of the first idea to solve the problem in the second.",
  "Make one shared ritual that gives both ideas a reason to exist.",
  "Let the audience of one become the creators of the other.",
  "Keep the smallest useful piece of each and discard the rest.",
  "Turn one idea into the learning experience that makes the other possible.",
  "Imagine both ideas as a single physical object. What does it do?",
  "What tension between these ideas could become their most interesting feature?",
  "Design a tiny experiment that tests something both ideas depend on.",
];

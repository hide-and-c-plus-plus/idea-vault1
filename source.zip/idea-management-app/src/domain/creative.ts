export type Energy = "low" | "steady" | "deep";
export type ExperimentVerdict =
  "untested" | "running" | "supported" | "challenged" | "inconclusive";
export interface Project {
  id: string;
  name: string;
  intention: string;
  color: string;
  created_at: number;
  idea_count?: number;
}
export interface ActionItem {
  id: string;
  idea_id: string;
  body: string;
  done_at: number | null;
  created_at: number;
}
export interface Experiment {
  id: string;
  idea_id: string;
  hypothesis: string;
  method: string;
  success_signal: string;
  result: string;
  verdict: ExperimentVerdict;
  created_at: number;
  updated_at: number;
}
export interface Capsule {
  id: string;
  idea_id: string | null;
  title: string;
  body: string;
  unlock_at: number;
  opened_at: number | null;
  created_at: number;
}
export interface FocusSession {
  id: string;
  idea_id: string | null;
  intention: string;
  notes: string;
  planned_seconds: number;
  elapsed_seconds: number;
  started_at: number;
  ends_at: number;
  completed_at: number | null;
  status: "running" | "completed" | "ended";
}
export interface ReviewEntry {
  id: string;
  learned: string;
  release_note: string;
  next_week: string;
  created_at: number;
}
export interface GraphEdge {
  id: string;
  source_idea_id: string;
  target_idea_id: string;
  link_type: string;
}
export interface SavedView {
  id: string;
  name: string;
  query: string;
  filters_json: string;
  created_at: number;
}
export interface ActivityDay {
  day: string;
  count: number;
}

export const ENERGY_LABELS: Record<Energy, string> = {
  low: "Gentle · low energy",
  steady: "Steady · some focus",
  deep: "Deep · full attention",
};
export const STAGE_LABELS: Record<string, string> = {
  spark: "Sparks",
  exploring: "Exploring",
  promising: "Promising",
  active: "In motion",
  done: "Realized",
  parked: "Incubating",
  dropped: "Released",
  archived: "Archived",
};

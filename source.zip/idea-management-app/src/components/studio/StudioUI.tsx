import React, { useState } from "react";
import {
  ActivityIndicator,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type TextInputProps,
  type ViewStyle,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { router } from "expo-router";
import { colors, radius } from "@/theme/tokens";
import { Body, Caption, H1, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import type { Idea } from "@/domain/types";
export function PageHeader({
  title,
  eyebrow,
  subtitle,
  back = false,
  right,
}: {
  title: string;
  eyebrow?: string;
  subtitle?: string;
  back?: boolean;
  right?: React.ReactNode;
}) {
  return (
    <View style={ui.header}>
      {back ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go back"
          onPress={() =>
            router.canGoBack() ? router.back() : router.replace("/" as any)
          }
          style={ui.back}
        >
          <Text style={ui.backText}>‹</Text>
        </Pressable>
      ) : null}
      <View style={{ flex: 1, gap: 5 }}>
        {eyebrow ? <Text style={ui.eyebrow}>{eyebrow}</Text> : null}
        <H1 style={{ fontSize: 30, lineHeight: 37 }}>{title}</H1>
        {subtitle ? <Secondary>{subtitle}</Secondary> : null}
      </View>
      {right}
    </View>
  );
}
export function Panel({
  children,
  style,
  accent,
}: {
  children: React.ReactNode;
  style?: ViewStyle;
  accent?: string;
}) {
  return (
    <View
      style={[ui.panel, accent ? { borderColor: accent } : undefined, style]}
    >
      {children}
    </View>
  );
}
export function Field({ label, ...props }: TextInputProps & { label: string }) {
  return (
    <View style={{ gap: 8 }}>
      <Text style={ui.label}>{label}</Text>
      <TextInput
        {...props}
        accessibilityLabel={label}
        placeholderTextColor={colors.textMuted}
        style={[
          ui.field,
          props.multiline && { minHeight: 120, textAlignVertical: "top" },
          props.style,
        ]}
      />
    </View>
  );
}
export function EmptyState({
  glyph = "✦",
  title,
  body,
  action,
}: {
  glyph?: string;
  title: string;
  body: string;
  action?: React.ReactNode;
}) {
  return (
    <View style={ui.empty}>
      <Text style={ui.emptyGlyph}>{glyph}</Text>
      <H2 style={{ textAlign: "center" }}>{title}</H2>
      <Secondary style={{ textAlign: "center" }}>{body}</Secondary>
      {action}
    </View>
  );
}
export function LoadState({
  loading,
  error,
  onRetry,
}: {
  loading: boolean;
  error?: string;
  onRetry: () => void;
}) {
  if (error)
    return (
      <Panel>
        <H2>Something interrupted the load</H2>
        <Secondary>{error}</Secondary>
        <Button label="Try again" variant="secondary" onPress={onRetry} />
      </Panel>
    );
  return loading ? (
    <View accessibilityLabel="Loading" style={{ padding: 28 }}>
      <ActivityIndicator color={colors.accent} />
    </View>
  ) : null;
}
export function ToolTile({
  glyph,
  title,
  description,
  onPress,
  color = colors.accent,
}: {
  glyph: string;
  title: string;
  description: string;
  onPress: () => void;
  color?: string;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${title}. ${description}`}
      onPress={onPress}
      style={({ pressed }) => [ui.tool, pressed && { opacity: 0.75 }]}
    >
      <View style={[ui.toolGlyphBox, { backgroundColor: color + "18" }]}>
        <Text style={[ui.toolGlyph, { color }]}>{glyph}</Text>
      </View>
      <View style={{ flex: 1, gap: 5 }}>
        <Body style={{ fontWeight: "700" }}>{title}</Body>
        <Secondary>{description}</Secondary>
      </View>
      <Text style={{ color: colors.textMuted, fontSize: 24 }}>›</Text>
    </Pressable>
  );
}
export function MiniStat({
  label,
  value,
  color = colors.accent,
}: {
  label: string;
  value: string | number;
  color?: string;
}) {
  return (
    <View style={{ flex: 1, minWidth: 80, gap: 5 }}>
      <Text style={{ color, fontSize: 27, fontWeight: "700" }}>{value}</Text>
      <Caption>{label}</Caption>
    </View>
  );
}
export function IdeaPicker({
  ideas,
  value,
  onChange,
  label = "Choose an idea",
  optional = false,
  exclude,
}: {
  ideas: Idea[];
  value: string;
  onChange: (id: string) => void;
  label?: string;
  optional?: boolean;
  exclude?: string;
}) {
  const [open, setOpen] = useState(false),
    [query, setQuery] = useState("");
  const chosen = ideas.find((i) => i.id === value);
  const options = ideas.filter(
    (i) =>
      i.id !== exclude &&
      `${i.title} ${i.snippet ?? ""}`
        .toLocaleLowerCase()
        .includes(query.toLocaleLowerCase()),
  );
  return (
    <View style={{ gap: 8 }}>
      <Text style={ui.label}>{label}</Text>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={`${label}: ${chosen?.title ?? "Select"}`}
        onPress={() => setOpen(true)}
        style={ui.picker}
      >
        <Body style={{ flex: 1 }} numberOfLines={2}>
          {chosen?.title ??
            (optional ? "No linked idea" : "Tap to choose an idea")}
        </Body>
        <Text style={{ color: colors.accent }}>⌄</Text>
      </Pressable>
      <Modal
        visible={open}
        transparent
        animationType="slide"
        onRequestClose={() => setOpen(false)}
      >
        <View style={ui.scrim}>
          <SafeAreaView style={ui.sheet}>
            <View style={ui.row}>
              <H2 style={{ flex: 1 }}>{label}</H2>
              <Button
                label="Close"
                variant="ghost"
                onPress={() => setOpen(false)}
              />
            </View>
            <Field
              label="Find an idea"
              value={query}
              onChangeText={setQuery}
              placeholder="Search titles and captures"
              autoCapitalize="none"
            />
            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ gap: 8, paddingBottom: 20 }}
            >
              {optional ? (
                <Button
                  label="No linked idea"
                  variant="secondary"
                  onPress={() => {
                    onChange("");
                    setOpen(false);
                  }}
                />
              ) : null}
              {options.slice(0, 80).map((i) => (
                <Pressable
                  key={i.id}
                  accessibilityRole="button"
                  onPress={() => {
                    onChange(i.id);
                    setOpen(false);
                  }}
                  style={ui.option}
                >
                  <Body numberOfLines={2}>{i.title || "Untitled idea"}</Body>
                  <Caption>{i.stage}</Caption>
                </Pressable>
              ))}
              {!options.length ? (
                <Secondary>No ideas found. Capture a thought first.</Secondary>
              ) : null}
            </ScrollView>
          </SafeAreaView>
        </View>
      </Modal>
    </View>
  );
}
export const ui = StyleSheet.create({
  header: {
    paddingTop: 20,
    paddingBottom: 24,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  eyebrow: {
    color: colors.accent,
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 2,
  },
  back: {
    width: 44,
    minHeight: 48,
    justifyContent: "center",
    alignItems: "center",
  },
  backText: { fontSize: 34, color: colors.textPrimary },
  panel: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: 20,
    gap: 14,
  },
  label: { color: colors.textSecondary, fontSize: 13, fontWeight: "600" },
  field: {
    minHeight: 52,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    backgroundColor: colors.surfaceRaised,
    color: colors.textPrimary,
    padding: 14,
    fontSize: 16,
    lineHeight: 24,
  },
  row: { flexDirection: "row", alignItems: "center", gap: 12 },
  wrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  stack: { gap: 16 },
  section: { marginTop: 28, gap: 14 },
  empty: {
    padding: 28,
    gap: 14,
    alignItems: "center",
    borderWidth: 1,
    borderStyle: "dashed",
    borderColor: colors.border,
    borderRadius: 20,
  },
  emptyGlyph: { color: colors.accent, fontSize: 32 },
  tool: {
    minHeight: 100,
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
    paddingVertical: 18,
    borderBottomColor: colors.border,
    borderBottomWidth: 1,
  },
  toolGlyphBox: {
    width: 48,
    height: 48,
    borderRadius: 15,
    justifyContent: "center",
    alignItems: "center",
  },
  toolGlyph: { fontSize: 25 },
  picker: {
    minHeight: 56,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 14,
    backgroundColor: colors.surfaceRaised,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  scrim: { flex: 1, backgroundColor: "#00000099", justifyContent: "flex-end" },
  sheet: {
    maxHeight: "85%",
    minHeight: "50%",
    backgroundColor: colors.bg,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 20,
    gap: 16,
  },
  option: {
    padding: 16,
    minHeight: 64,
    backgroundColor: colors.surfaceRaised,
    borderRadius: 12,
    gap: 6,
  },
});

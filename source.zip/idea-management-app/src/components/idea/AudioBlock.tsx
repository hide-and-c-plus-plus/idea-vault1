import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { useAudioPlayer } from "expo-audio";
import { Caption, Secondary } from "@/components/ui/Typography";
import { colors, radius, spacing } from "@/theme/tokens";

export function AudioBlock({
  uri,
  durationMs,
}: {
  uri: string;
  durationMs?: number | null;
}) {
  const player = useAudioPlayer(uri);
  const [playing, setPlaying] = useState(false);
  const toggle = () => {
    if (playing) {
      player.pause();
      setPlaying(false);
    } else {
      player.play();
      setPlaying(true);
    }
  };
  return (
    <View style={styles.card}>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={playing ? "Pause recording" : "Play recording"}
        onPress={toggle}
        style={styles.play}
      >
        <Text style={styles.glyph}>{playing ? "Ⅱ" : "▶"}</Text>
      </Pressable>
      <View style={{ flex: 1 }}>
        <Secondary>Voice capture</Secondary>
        <Caption>
          {durationMs
            ? `${Math.round(durationMs / 1000)} seconds`
            : "Original audio retained"}
        </Caption>
      </View>
      <Pressable
        onPress={() =>
          player.seekTo(Math.max(0, (player.currentTime ?? 0) - 15))
        }
        style={styles.seek}
      >
        <Caption>−15s</Caption>
      </Pressable>
      <Pressable
        onPress={() => player.seekTo((player.currentTime ?? 0) + 15)}
        style={styles.seek}
      >
        <Caption>+15s</Caption>
      </Pressable>
    </View>
  );
}
const styles = StyleSheet.create({
  card: {
    minHeight: 72,
    borderRadius: radius.md,
    backgroundColor: colors.surfaceRaised,
    borderWidth: 1,
    borderColor: colors.border,
    padding: spacing.md,
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.md,
  },
  play: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.accentSoft,
    alignItems: "center",
    justifyContent: "center",
  },
  glyph: { color: colors.textPrimary, fontSize: 18 },
  seek: {
    minWidth: 48,
    minHeight: 48,
    alignItems: "center",
    justifyContent: "center",
  },
});

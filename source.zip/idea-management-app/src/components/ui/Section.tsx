import React from "react";
import { StyleSheet, View } from "react-native";
import { H2, Secondary } from "./Typography";
import { spacing } from "@/theme/tokens";
export function Section({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <View style={styles.section}>
      <View style={styles.head}>
        <H2>{title}</H2>
        {subtitle ? <Secondary>{subtitle}</Secondary> : null}
      </View>
      {children}
    </View>
  );
}
const styles = StyleSheet.create({
  section: { marginTop: spacing.xl, gap: spacing.md },
  head: { gap: 2 },
});

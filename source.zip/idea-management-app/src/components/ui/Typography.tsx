import React from "react";
import { Text, type TextProps, StyleSheet } from "react-native";
import { colors } from "@/theme/tokens";

export function Display(props: TextProps) {
  return <Text {...props} style={[styles.display, props.style]} />;
}
export function H1(props: TextProps) {
  return <Text {...props} style={[styles.h1, props.style]} />;
}
export function H2(props: TextProps) {
  return <Text {...props} style={[styles.h2, props.style]} />;
}
export function Body(props: TextProps) {
  return <Text {...props} style={[styles.body, props.style]} />;
}
export function Secondary(props: TextProps) {
  return <Text {...props} style={[styles.secondary, props.style]} />;
}
export function Caption(props: TextProps) {
  return <Text {...props} style={[styles.caption, props.style]} />;
}

const styles = StyleSheet.create({
  display: {
    color: colors.textPrimary,
    fontSize: 28,
    lineHeight: 34,
    fontWeight: "600",
  },
  h1: {
    color: colors.textPrimary,
    fontSize: 24,
    lineHeight: 30,
    fontWeight: "600",
  },
  h2: {
    color: colors.textPrimary,
    fontSize: 20,
    lineHeight: 26,
    fontWeight: "600",
  },
  body: { color: colors.textPrimary, fontSize: 16, lineHeight: 24 },
  secondary: { color: colors.textSecondary, fontSize: 14, lineHeight: 20 },
  caption: { color: colors.textMuted, fontSize: 12, lineHeight: 16 },
});

export { ErrorBoundary } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  StyleSheet,
  Text,
  View,
  Pressable,
  Platform,
} from "react-native";
import { Stack, router } from "expo-router";
import { StatusBar } from "expo-status-bar";
import * as Notifications from "expo-notifications";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { runMigrations } from "@/db/migrations";
import { configureNotificationChannels } from "@/services/notifications";
import { DataChangeProvider } from "@/state/DataChangeContext";
import { purgeExpiredTrash } from "@/services/maintenance";
import { FeedbackProvider } from "@/state/FeedbackContext";
import { colors } from "@/theme/tokens";

function useNotificationObserver(enabled: boolean) {
  useEffect(() => {
    if (!enabled || Platform.OS === "web") return;
    const redirect = (notification: Notifications.Notification) => {
      const url = notification.request.content.data?.url;
      if (typeof url === "string" && /^\/idea\/[A-Za-z0-9_-]+$/.test(url))
        router.push(url as any);
    };
    const response = Notifications.getLastNotificationResponse();
    if (response?.notification) redirect(response.notification);
    const sub = Notifications.addNotificationResponseReceivedListener((next) =>
      redirect(next.notification),
    );
    return () => sub.remove();
  }, [enabled]);
}

export default function RootLayout() {
  const [attempt, setAttempt] = useState(0);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  useNotificationObserver(ready);
  useEffect(() => {
    (async () => {
      try {
        await runMigrations();
        await configureNotificationChannels().catch(() => undefined);
        await purgeExpiredTrash();
        setReady(true);
      } catch (e) {
        setError(e as Error);
      }
    })();
  }, [attempt]);

  if (!ready)
    return (
      <View style={styles.loading}>
        <StatusBar style="light" />
        {error ? (
          <>
            <Text style={styles.errorTitle}>Could not open Idea Vault</Text>
            <Text style={styles.errorBody}>{error.message}</Text>
            <Pressable
              accessibilityRole="button"
              onPress={() => {
                setError(null);
                setAttempt((v) => v + 1);
              }}
              style={{ padding: 16 }}
            >
              <Text style={{ color: colors.accent }}>Try again</Text>
            </Pressable>
          </>
        ) : (
          <ActivityIndicator color={colors.accent} />
        )}
      </View>
    );
  return (
    <SafeAreaProvider>
      <DataChangeProvider>
        <FeedbackProvider>
          <StatusBar style="light" />
          <Stack
            screenOptions={{
              headerShown: false,
              contentStyle: { backgroundColor: colors.bg },
              animation: "fade",
            }}
          >
            <Stack.Screen name="(tabs)" />
            <Stack.Screen
              name="capture"
              options={{
                presentation: "modal",
                animation: "slide_from_bottom",
              }}
            />
            <Stack.Screen name="idea/[id]" />
            <Stack.Screen name="idea/[id]/develop" />
            <Stack.Screen name="idea/[id]/reminder" />
            <Stack.Screen name="idea/[id]/link" />
            <Stack.Screen name="settings/index" />
            <Stack.Screen name="settings/trash" />
          </Stack>
        </FeedbackProvider>
      </DataChangeProvider>
    </SafeAreaProvider>
  );
}
const styles = StyleSheet.create({
  loading: {
    flex: 1,
    backgroundColor: colors.bg,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    gap: 12,
  },
  errorTitle: {
    color: colors.textPrimary,
    fontSize: 18,
    fontWeight: "600",
    textAlign: "center",
  },
  errorBody: { color: colors.textSecondary, fontSize: 14, textAlign: "center" },
});

import React from "react";
import { Alert, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { PageHeader, Panel, ui } from "@/components/studio/StudioUI";
import { exportAllData } from "@/services/export";
import { importTextIdea } from "@/services/import";
import { getSetting, seedPlayground } from "@/db/repositories/creative";
import { useAction, useLoad } from "@/hooks/useAsync";
export default function SettingsScreen() {
  const action = useAction(),
    load = useLoad(() => getSetting("playground_added"));
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="YOUR IDEAS, YOUR TERMS"
        title="Settings"
        subtitle="A private creative workshop that works offline."
      />
      <View style={ui.stack}>
        <Panel>
          <H2>Take your work with you</H2>
          <Secondary>
            Export your ideas, original media, connections, projects, tasks,
            experiments, capsules, focus sessions, and review reflections.
          </Secondary>
          <Button
            label="Export everything as a ZIP"
            loading={action.busy}
            onPress={() => action.run(() => exportAllData(), "Export prepared")}
          />
          <Button
            label="Import a text or Markdown note"
            variant="secondary"
            disabled={action.busy}
            onPress={() =>
              action.run(async () => {
                const id = await importTextIdea();
                if (id) router.push(`/idea/${id}` as any);
              })
            }
          />
          <Caption>
            Import creates one new idea from a text note. Full ZIP restore is
            not supported. Capsule letters are included in plain text in the
            export.
          </Caption>
        </Panel>
        <Panel>
          <H2>Try the playground</H2>
          <Secondary>
            Add a small set of clearly labeled example ideas and connections to
            explore the Atlas and Collision lab. Your existing ideas stay as
            they are.
          </Secondary>
          <Button
            label={
              load.data ? "Playground already added" : "Add playground ideas"
            }
            variant="secondary"
            disabled={!!load.data || action.busy || load.loading}
            onPress={() =>
              Alert.alert(
                "Add the playground?",
                "This adds six labeled sample ideas to your vault. You can move them to Trash later.",
                [
                  { text: "Not now", style: "cancel" },
                  {
                    text: "Add examples",
                    onPress: () =>
                      action.run(
                        () => seedPlayground(),
                        "Playground ideas added",
                      ),
                  },
                ],
              )
            }
          />
        </Panel>
        <Panel>
          <H2>Make room</H2>
          <Button
            label="Open Trash"
            variant="secondary"
            onPress={() => router.push("/settings/trash" as any)}
          />
          <Secondary>
            Trashed ideas can be restored for 30 days. Deleting a project room
            leaves its ideas in your vault.
          </Secondary>
        </Panel>
        <Panel>
          <H2>Private by default</H2>
          <Body>No account. No analytics. No remote AI.</Body>
          <Secondary>
            Creative prompts are built into the app. Atlas suggestions use
            shared words in your saved ideas. Your notes stay on your device
            unless you choose to share or export them.
          </Secondary>
          <Caption>
            The vault uses normal app storage, not encrypted storage or an app
            lock. Your device’s lock screen is your first protection.
            Uninstalling the app may remove local data; export work you want to
            keep.
          </Caption>
        </Panel>
        <Panel>
          <H2>Find your way</H2>
          <Secondary>
            Today brings back open loops. Vault keeps your ideas searchable.
            Studio helps you reshape them. Atlas follows their connections.
            Review helps you notice what changed.
          </Secondary>
          <Button
            label="Open the Studio"
            variant="ghost"
            onPress={() => router.push("/studio" as any)}
          />
        </Panel>
        <Caption style={{ textAlign: "center", marginTop: 20 }}>
          IDEA VAULT · CREATIVE STUDIO EDITION · 2.0
        </Caption>
      </View>
    </Screen>
  );
}

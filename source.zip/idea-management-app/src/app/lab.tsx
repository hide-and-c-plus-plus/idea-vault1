import React, { useState } from "react";
import { Share, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import {
  EmptyState,
  Field,
  IdeaPicker,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import { addTextBlock, getIdea, listIdeas } from "@/db/repositories/ideas";
import { createBranch } from "@/db/repositories/creative";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import {
  COLLISION_BRIDGES,
  CONSTRAINTS,
  LENSES,
  REMIX_CARDS,
} from "@/domain/prompts";
import { shuffle } from "@/domain/logic";
import { colors } from "@/theme/tokens";
const tools: Record<string, { title: string; description: string }> = {
  collision: {
    title: "Collision lab",
    description: "Two familiar ideas. One unfamiliar possibility.",
  },
  remix: {
    title: "Remix deck",
    description: "Change one ingredient. Find a different idea.",
  },
  council: {
    title: "Council of perspectives",
    description: "Let an idea speak to more than one point of view.",
  },
  constraints: {
    title: "Constraint roulette",
    description: "Make the restriction the interesting part.",
  },
  assumptions: {
    title: "Assumption ladder",
    description: "Climb down from certainty to something testable.",
  },
  pitch: {
    title: "One-page pitch",
    description: "Give a scattered thought a clear shape.",
  },
};
export default function LabScreen() {
  const params = useLocalSearchParams<{ tool?: string; idea?: string }>();
  const tool = tools[params.tool ?? ""] ? params.tool! : "collision";
  const config = tools[tool]!;
  const form = useDraftForm(`studio:${tool}:${params.idea ?? "any"}`, {
    first: params.idea ?? "",
    second: "",
    title: "",
    body: "",
    card: 0,
    branch: false,
  });
  const { value: f, setValue: set } = form;
  const patch = (p: Partial<typeof f>) => set((v) => ({ ...v, ...p }));
  const action = useAction();
  const load = useLoad(() => listIdeas({ limit: 500 }));
  const ideas = load.data ?? [];
  const [saved, setSaved] = useState(false);
  const source = ideas.find((i) => i.id === f.first);
  const needsIdea = [
    "collision",
    "remix",
    "council",
    "assumptions",
    "pitch",
  ].includes(tool);
  const cards = tool === "remix" ? REMIX_CARDS : LENSES;
  const card = cards[f.card % cards.length]!;
  const prompt =
    tool === "collision"
      ? COLLISION_BRIDGES[f.card % COLLISION_BRIDGES.length]!
      : tool === "constraints"
        ? CONSTRAINTS[f.card % CONSTRAINTS.length]!
        : tool === "assumptions"
          ? "What am I assuming? What have I actually observed? What small test could prove the assumption wrong?"
          : tool === "pitch"
            ? "Lead with a specific person, their problem, your promise, and a small next step."
            : card.prompt;
  const spin = () => patch({ card: f.card + 1 });
  const save = () =>
    action.run(async () => {
      if (needsIdea && !source)
        throw new Error("Choose an idea to start with.");
      if (tool === "collision" && (!f.second || f.second === f.first))
        throw new Error("Choose two different ideas.");
      if (!f.body.trim()) throw new Error("Write your response first.");
      const body = `${config.title}${tool === "remix" || tool === "council" ? ` · ${card.title}` : ""}\n\nPrompt: ${prompt}\n\n${f.body.trim()}`;
      let destination = f.first;
      if (["collision", "constraints"].includes(tool) || f.branch) {
        destination = await createBranch({
          title:
            f.title.trim() ||
            `${config.title}: ${source?.title ?? "a new possibility"}`,
          body,
          parents: [
            f.first,
            ...(tool === "collision" ? [f.second] : []),
          ].filter(Boolean),
          source: tool === "collision" ? "collision_lab" : tool,
        });
      } else await addTextBlock(f.first, body);
      await form.clear();
      setSaved(true);
      router.replace(`/idea/${destination}` as any);
    }, "Saved to your vault");
  const buildPitch = () =>
    action.run(async () => {
      if (!f.first) throw new Error("Choose an idea first.");
      const i = await getIdea(f.first);
      if (!i) throw new Error("Idea not found.");
      patch({
        body: `${i.title}\n\nFOR\n${i.audience || "[Who is this for?]"}\n\nTHE PROBLEM\n${i.problem || "[What is hard today?]"}\n\nTHE IDEA\n${i.summary || i.blocks.find((b) => b.type === "text")?.body_text || "[What changes?]"}\n\nWHY NOW\n${i.why_now || "[Why does this matter now?]"}\n\nSMALLEST TEST\n${i.next_experiment || "[How could you test this?]"}\n\nNEXT MOVE\n${i.next_action || "[One concrete step]"}\n\nSUCCESS LOOKS LIKE\n${i.done_definition || "[What would a useful result be?]"}`,
      });
    });
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="CREATIVE STUDIO"
        title={config.title}
        subtitle={config.description}
      />
      <LoadState
        loading={load.loading || !form.ready}
        error={load.error}
        onRetry={load.reload}
      />
      {form.ready ? (
        <View style={ui.stack}>
          {!ideas.length && needsIdea ? (
            <EmptyState
              title="Give the lab something to work with"
              body={
                tool === "collision"
                  ? "Capture two different ideas, then bring them together here."
                  : "Capture one thought, then come back to explore it."
              }
              action={
                <Button
                  label="Capture an idea"
                  onPress={() => router.push("/capture" as any)}
                />
              }
            />
          ) : null}
          <IdeaPicker
            label={
              tool === "collision" ? "Ingredient one" : "Your starting idea"
            }
            ideas={ideas}
            value={f.first}
            onChange={(first) =>
              patch({ first, second: first === f.second ? "" : f.second })
            }
            optional={!needsIdea}
            exclude={f.second}
          />
          {tool === "collision" ? (
            <>
              <IdeaPicker
                label="Ingredient two"
                ideas={ideas}
                value={f.second}
                onChange={(second) => patch({ second })}
                exclude={f.first}
              />
              <Button
                label="Find an unexpected pair ⇄"
                disabled={ideas.length < 2}
                variant="secondary"
                onPress={() => {
                  const pair = shuffle(ideas);
                  patch({
                    first: pair[0]!.id,
                    second: pair[1]!.id,
                    card: f.card + 1,
                  });
                }}
              />
            </>
          ) : null}
          {tool === "remix" || tool === "council" ? (
            <View style={ui.wrap}>
              {cards.map((c, index) => (
                <Chip
                  key={c.id}
                  label={c.title}
                  selected={f.card % cards.length === index}
                  onPress={() => patch({ card: index })}
                />
              ))}
            </View>
          ) : null}
          <Panel accent={colors.accent + "70"}>
            <Caption style={{ color: colors.accent }}>
              {tool === "collision"
                ? "THE BRIDGE"
                : tool === "constraints"
                  ? "YOUR CREATIVE CONSTRAINT"
                  : tool === "remix" || tool === "council"
                    ? card.title.toUpperCase()
                    : "THE EXERCISE"}
            </Caption>
            <H2>{prompt}</H2>
            {tool === "remix" || tool === "council" ? (
              <Secondary>{card.hint}</Secondary>
            ) : null}
            {["collision", "constraints"].includes(tool) ? (
              <Button
                label="Try another prompt ↻"
                variant="ghost"
                onPress={spin}
              />
            ) : null}
          </Panel>
          {tool === "pitch" ? (
            <Button
              label="Build a draft from my idea"
              variant="secondary"
              disabled={action.busy || !f.first}
              onPress={buildPitch}
            />
          ) : null}
          {["collision", "constraints"].includes(tool) || f.branch ? (
            <Field
              label="Name this new possibility"
              value={f.title}
              onChangeText={(title) => patch({ title })}
              placeholder="A name to find it again"
              maxLength={180}
            />
          ) : null}
          <Field
            label={tool === "pitch" ? "Your editable pitch" : "Your response"}
            value={f.body}
            onChangeText={(body) => patch({ body })}
            multiline
            style={{ minHeight: 220 }}
            placeholder={
              tool === "assumptions"
                ? "I assume…\n\nI actually observed…\n\nI could be wrong if…\n\nThe smallest test…"
                : "Follow the prompt. Keep the specific, surprising parts."
            }
          />
          {!["collision", "constraints"].includes(tool) ? (
            <Chip
              label="Save as a new branch"
              selected={f.branch}
              onPress={() => patch({ branch: !f.branch })}
            />
          ) : null}
          <Caption>Your draft is kept on this device as you write.</Caption>
          <Button
            label={
              tool === "collision"
                ? "Create the offspring ✦"
                : f.branch || tool === "constraints"
                  ? "Save a new idea"
                  : "Save to idea timeline"
            }
            loading={action.busy}
            disabled={saved || !f.body.trim()}
            onPress={save}
          />
          {tool === "pitch" ? (
            <Button
              label="Share this pitch"
              variant="secondary"
              disabled={!f.body.trim()}
              onPress={() => action.run(() => Share.share({ message: f.body }))}
            />
          ) : null}
        </View>
      ) : null}
    </Screen>
  );
}

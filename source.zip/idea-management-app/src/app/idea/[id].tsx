import React, { useEffect, useState } from "react";
import {
  Alert,
  Image,
  Modal,
  Pressable,
  Share,
  Text,
  View,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import * as Sharing from "expo-sharing";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { AudioBlock } from "@/components/idea/AudioBlock";
import {
  EmptyState,
  Field,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import {
  addAttachmentBlock,
  addTextBlock,
  getIdea,
  listCategories,
  setTags,
  softDeleteIdea,
  updateIdea,
} from "@/db/repositories/ideas";
import {
  addAction,
  ideaEvents,
  listActions,
  listProjects,
  projectMembership,
  removeAction,
  toggleAction,
  toggleProjectIdea,
} from "@/db/repositories/creative";
import { listConnections, removeIdeaLink } from "@/db/repositories/links";
import type { IdeaStage } from "@/domain/types";
import { ENERGY_LABELS, STAGE_LABELS } from "@/domain/creative";
import {
  importFileAttachment,
  importImageAttachment,
} from "@/services/attachments";
import { singleIdeaMarkdown } from "@/services/export";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { formatDateTime } from "@/utils/date";
import { colors } from "@/theme/tokens";
const stages: IdeaStage[] = [
  "spark",
  "exploring",
  "promising",
  "active",
  "done",
  "parked",
  "dropped",
  "archived",
];
export default function IdeaDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>(),
    action = useAction();
  const [organize, setOrganize] = useState(false),
    [renaming, setRenaming] = useState(false),
    [history, setHistory] = useState(false),
    [title, setTitle] = useState(""),
    [tags, setTagText] = useState(""),
    [task, setTask] = useState(""),
    [preview, setPreview] = useState<string | null>(null);
  const thought = useDraftForm(`thought:${id}`, { body: "" });
  const load = useLoad(async () => {
    const [
      idea,
      categories,
      connections,
      actions,
      projects,
      membership,
      events,
    ] = await Promise.all([
      getIdea(id),
      listCategories(),
      listConnections(id),
      listActions(id),
      listProjects(),
      projectMembership(id),
      ideaEvents(id),
    ]);
    return {
      idea,
      categories,
      connections,
      actions,
      projects,
      membership,
      events,
    };
  }, [id]);
  const idea = load.data?.idea;
  useEffect(() => {
    if (idea) {
      setTitle(idea.title ?? "");
      setTagText(idea.tags.map((t) => t.name).join(", "));
    }
  }, [idea?.id]);
  const go = (path: string) => router.push(path as any);
  const trash = () =>
    Alert.alert(
      "Move to Trash?",
      "You can restore this idea for 30 days. Its reminders will be canceled.",
      [
        { text: "Keep it", style: "cancel" },
        {
          text: "Move to Trash",
          style: "destructive",
          onPress: () =>
            action.run(async () => {
              await softDeleteIdea(id);
              router.canGoBack() ? router.back() : router.replace("/" as any);
            }, "Moved to Trash"),
        },
      ],
    );
  const shareAttachment = (uri: string, mime: string | null) =>
    action.run(async () => {
      if (!(await Sharing.isAvailableAsync()))
        throw new Error("Attachment sharing is unavailable on this device.");
      await Sharing.shareAsync(uri, { mimeType: mime ?? undefined });
    });
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="A THOUGHT IN PROGRESS"
        title="Your idea"
        right={
          idea ? (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel={
                idea.is_starred ? "Remove from shortlist" : "Add to shortlist"
              }
              accessibilityState={{ selected: !!idea.is_starred }}
              aria-pressed={!!idea.is_starred}
              onPress={() =>
                action.run(
                  () => updateIdea(id, { is_starred: idea.is_starred ? 0 : 1 }),
                  idea.is_starred
                    ? "Removed from shortlist"
                    : "Added to shortlist",
                )
              }
              style={{
                width: 48,
                height: 48,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Text
                style={{
                  color: idea.is_starred ? colors.warning : colors.textMuted,
                  fontSize: 29,
                }}
              >
                {idea.is_starred ? "★" : "☆"}
              </Text>
            </Pressable>
          ) : undefined
        }
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {load.data && !idea ? (
        <EmptyState
          title="This idea is not here"
          body="It may be in Trash, or the link may be out of date."
          action={
            <Button
              label="Open Trash"
              variant="secondary"
              onPress={() => go("/settings/trash")}
            />
          }
        />
      ) : null}
      {idea && load.data ? (
        <View style={ui.stack}>
          {renaming ? (
            <Panel>
              <Field
                label="Idea title"
                value={title}
                onChangeText={setTitle}
                multiline
                maxLength={180}
              />
              <Button
                label="Save title"
                disabled={!title.trim()}
                loading={action.busy}
                onPress={() =>
                  action.run(async () => {
                    await updateIdea(id, { title: title.trim() });
                    setRenaming(false);
                  }, "Title saved")
                }
              />
              <Button
                label="Cancel"
                variant="ghost"
                onPress={() => {
                  setTitle(idea.title ?? "");
                  setRenaming(false);
                }}
              />
            </Panel>
          ) : (
            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Rename this idea"
              onPress={() => {
                setTitle(idea.title ?? "");
                setRenaming(true);
              }}
            >
              <Text
                style={{
                  color: colors.textPrimary,
                  fontSize: 29,
                  lineHeight: 38,
                  fontWeight: "600",
                }}
              >
                {idea.title || "Untitled idea"}
              </Text>
              <Caption style={{ marginTop: 8 }}>
                Tap title to rename · Captured {formatDateTime(idea.created_at)}
              </Caption>
            </Pressable>
          )}
          <View style={ui.wrap}>
            {stages.map((stage) => (
              <Chip
                key={stage}
                label={STAGE_LABELS[stage]!}
                selected={idea.stage === stage}
                onPress={() => action.run(() => updateIdea(id, { stage }))}
              />
            ))}
          </View>
          <View style={ui.row}>
            <Button
              label="◷ Focus"
              style={{ flex: 1 }}
              onPress={() => go(`/focus?idea=${id}`)}
            />
            <Button
              label="✧ Remix"
              variant="secondary"
              style={{ flex: 1 }}
              onPress={() => go(`/lab?tool=remix&idea=${id}`)}
            />
          </View>
          <View style={ui.wrap}>
            <Chip
              label="⚗ Test an assumption"
              onPress={() => go(`/experiments?idea=${id}`)}
            />
            <Chip
              label="⌁ Time capsule"
              onPress={() => go(`/capsules?idea=${id}`)}
            />
            <Chip
              label="↗ Pitch"
              onPress={() => go(`/lab?tool=pitch&idea=${id}`)}
            />
            <Chip
              label="◉ Perspectives"
              onPress={() => go(`/lab?tool=council&idea=${id}`)}
            />
          </View>
          <View style={ui.section}>
            <H2>The next small moves</H2>
            <Secondary>Make the next action smaller than the idea.</Secondary>
            {load.data.actions.map((a) => (
              <View key={a.id} style={ui.row}>
                <Pressable
                  accessibilityRole="checkbox"
                  accessibilityState={{ checked: !!a.done_at }}
                  aria-checked={!!a.done_at}
                  accessibilityLabel={a.body}
                  onPress={() => action.run(() => toggleAction(a.id))}
                  style={{
                    flex: 1,
                    flexDirection: "row",
                    alignItems: "center",
                    gap: 12,
                    minHeight: 52,
                    padding: 12,
                    backgroundColor: colors.surface,
                    borderRadius: 12,
                  }}
                >
                  <Text
                    style={{
                      color: a.done_at ? colors.success : colors.accent,
                      fontSize: 23,
                    }}
                  >
                    {a.done_at ? "☑" : "□"}
                  </Text>
                  <Body
                    style={{
                      flex: 1,
                      textDecorationLine: a.done_at ? "line-through" : "none",
                      color: a.done_at ? colors.textMuted : colors.textPrimary,
                    }}
                  >
                    {a.body}
                  </Body>
                </Pressable>
                <Pressable
                  accessibilityRole="button"
                  accessibilityLabel={`Delete task: ${a.body}`}
                  onPress={() =>
                    Alert.alert(
                      "Remove this task?",
                      "The idea will stay in your vault.",
                      [
                        { text: "Keep", style: "cancel" },
                        {
                          text: "Remove",
                          style: "destructive",
                          onPress: () => action.run(() => removeAction(a.id)),
                        },
                      ],
                    )
                  }
                  style={{
                    width: 48,
                    height: 48,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Text style={{ color: colors.textMuted, fontSize: 22 }}>
                    ×
                  </Text>
                </Pressable>
              </View>
            ))}
            <Field
              label="One next move"
              value={task}
              onChangeText={setTask}
              placeholder="Ask one person. Sketch one screen."
              maxLength={500}
            />
            <Button
              label="Add next move"
              variant="secondary"
              disabled={!task.trim()}
              loading={action.busy}
              onPress={() =>
                action.run(async () => {
                  await addAction(id, task);
                  setTask("");
                }, "Next move added")
              }
            />
          </View>
          <View style={ui.section}>
            <H2>Thoughts & evidence</H2>
            {idea.blocks.map((block) => {
              const a = idea.attachments.find(
                (a) => a.id === block.attachment_id,
              );
              return (
                <Panel
                  key={block.id}
                  accent={block.is_original ? colors.accent + "50" : undefined}
                >
                  <Caption>
                    {block.is_original ? "ORIGINAL CAPTURE" : "LATER THOUGHT"} ·{" "}
                    {formatDateTime(block.created_at)}
                  </Caption>
                  {block.type === "text" ? (
                    <Body selectable>{block.body_text || "Media capture"}</Body>
                  ) : block.type === "audio" && a ? (
                    <AudioBlock uri={a.local_uri} durationMs={a.duration_ms} />
                  ) : block.type === "image" && a ? (
                    <>
                      <Pressable
                        accessibilityRole="button"
                        accessibilityLabel="View attached image"
                        onPress={() => setPreview(a.local_uri)}
                      >
                        <Image
                          source={{ uri: a.local_uri }}
                          style={{
                            width: "100%",
                            height: 210,
                            borderRadius: 12,
                          }}
                          resizeMode="cover"
                        />
                      </Pressable>
                      <Button
                        label="Share image"
                        variant="ghost"
                        onPress={() =>
                          shareAttachment(a.local_uri, a.mime_type)
                        }
                      />
                    </>
                  ) : a ? (
                    <>
                      <Secondary>{a.local_uri.split("/").pop()}</Secondary>
                      <Button
                        label="Open / share attachment"
                        variant="secondary"
                        onPress={() =>
                          shareAttachment(a.local_uri, a.mime_type)
                        }
                      />
                    </>
                  ) : (
                    <Secondary>{block.body_text ?? block.type}</Secondary>
                  )}
                </Panel>
              );
            })}
            <Field
              label="Add a new thought"
              value={thought.value.body}
              onChangeText={(body) => {
                thought.resume();
                thought.setValue({ body });
              }}
              multiline
              placeholder="What changed? What did you learn? Your original capture stays intact."
            />
            <Button
              label="Keep this thought"
              loading={action.busy}
              disabled={!thought.value.body.trim() || !thought.ready}
              onPress={() =>
                action.run(async () => {
                  await addTextBlock(id, thought.value.body);
                  await thought.clear();
                  thought.setValue({ body: "" });
                }, "Thought added")
              }
            />
            <View style={ui.row}>
              <Button
                label="Attach image"
                variant="secondary"
                style={{ flex: 1 }}
                onPress={() =>
                  action.run(async () => {
                    const a = await importImageAttachment();
                    if (a)
                      await addAttachmentBlock(id, {
                        type: "image",
                        uri: a.uri,
                        mimeType: a.mimeType,
                      });
                  })
                }
              />
              <Button
                label="Attach file"
                variant="secondary"
                style={{ flex: 1 }}
                onPress={() =>
                  action.run(async () => {
                    const a = await importFileAttachment();
                    if (a)
                      await addAttachmentBlock(id, {
                        type: "file",
                        uri: a.uri,
                        mimeType: a.mimeType,
                      });
                  })
                }
              />
            </View>
          </View>
          <View style={ui.section}>
            <H2>Connected possibilities</H2>
            {load.data.connections.map((c) => (
              <Panel key={c.id}>
                <Pressable
                  accessibilityRole="button"
                  onPress={() => go(`/idea/${c.other_id}`)}
                >
                  <Caption>
                    {c.direction === "incoming" ? "←" : "→"}{" "}
                    {c.link_type.replaceAll("_", " ")}
                  </Caption>
                  <Body style={{ marginTop: 8 }}>
                    {c.other_title || "Untitled idea"}
                  </Body>
                </Pressable>
                {c.note ? <Secondary>{c.note}</Secondary> : null}
                <Button
                  label="Remove this connection"
                  variant="ghost"
                  onPress={() =>
                    action.run(() => removeIdeaLink(c.id), "Connection removed")
                  }
                />
              </Panel>
            ))}
            {!load.data.connections.length ? (
              <Secondary>
                No connections yet. This might be the beginning of a new
                constellation.
              </Secondary>
            ) : null}
            <Button
              label="Link another idea"
              variant="secondary"
              onPress={() => go(`/idea/${id}/link`)}
            />
          </View>
          <View style={ui.section}>
            <Button
              label={
                organize
                  ? "Close organization"
                  : "Organize · energy, tags, horizon, projects"
              }
              variant="secondary"
              onPress={() => setOrganize(!organize)}
            />
            {organize ? (
              <Panel>
                <Caption>ATTENTION THIS IDEA NEEDS</Caption>
                <View style={ui.wrap}>
                  {(["low", "steady", "deep"] as const).map((energy) => (
                    <Chip
                      key={energy}
                      label={ENERGY_LABELS[energy]}
                      selected={idea.energy === energy}
                      onPress={() =>
                        action.run(() => updateIdea(id, { energy }))
                      }
                    />
                  ))}
                </View>
                <Caption>HORIZON</Caption>
                <View style={ui.wrap}>
                  <Chip
                    label="None"
                    selected={!idea.horizon}
                    onPress={() =>
                      action.run(() => updateIdea(id, { horizon: null }))
                    }
                  />
                  {(
                    [
                      "now",
                      "soon",
                      "someday",
                      "evergreen",
                      "time-sensitive",
                    ] as const
                  ).map((horizon) => (
                    <Chip
                      key={horizon}
                      label={horizon}
                      selected={idea.horizon === horizon}
                      onPress={() =>
                        action.run(() => updateIdea(id, { horizon }))
                      }
                    />
                  ))}
                </View>
                <Caption>CATEGORY</Caption>
                <View style={ui.wrap}>
                  <Chip
                    label="None"
                    selected={!idea.primary_category_id}
                    onPress={() =>
                      action.run(() =>
                        updateIdea(id, { primary_category_id: null }),
                      )
                    }
                  />
                  {load.data.categories.map((c) => (
                    <Chip
                      key={c.id}
                      label={c.name}
                      selected={idea.primary_category_id === c.id}
                      onPress={() =>
                        action.run(() =>
                          updateIdea(id, { primary_category_id: c.id }),
                        )
                      }
                    />
                  ))}
                </View>
                <Field
                  label="Tags, separated by commas"
                  value={tags}
                  onChangeText={setTagText}
                  placeholder="learning, android, tiny-experiments"
                />
                <Button
                  label="Save tags"
                  variant="secondary"
                  onPress={() =>
                    action.run(() => setTags(id, tags.split(",")), "Tags saved")
                  }
                />
                <Caption>PROJECT ROOMS</Caption>
                <View style={ui.wrap}>
                  {load.data.projects.map((p) => (
                    <Chip
                      key={p.id}
                      label={p.name}
                      selected={load.data!.membership.some(
                        (m) => m.project_id === p.id,
                      )}
                      onPress={() =>
                        action.run(() => toggleProjectIdea(p.id, id))
                      }
                    />
                  ))}
                </View>
                <Button
                  label="Manage project rooms"
                  variant="ghost"
                  onPress={() => go("/projects")}
                />
              </Panel>
            ) : null}
          </View>
          <View style={ui.section}>
            <H2>Give it a direction</H2>
            {idea.next_action ? (
              <Panel>
                <Caption>NEXT ACTION</Caption>
                <Body>{idea.next_action}</Body>
              </Panel>
            ) : null}
            <Button
              label="Develop the idea brief"
              variant="secondary"
              onPress={() => go(`/idea/${id}/develop`)}
            />
            <Button
              label="Set a reminder"
              variant="secondary"
              onPress={() => go(`/idea/${id}/reminder`)}
            />
            <Button
              label="Share as a Markdown brief"
              variant="secondary"
              onPress={() =>
                action.run(async () =>
                  Share.share({ message: await singleIdeaMarkdown(id) }),
                )
              }
            />
          </View>
          <View style={ui.section}>
            <Button
              label={history ? "Hide history" : "View idea history"}
              variant="ghost"
              onPress={() => setHistory(!history)}
            />
            {history
              ? load.data.events.map((e) => (
                  <View
                    key={e.id}
                    style={{
                      borderLeftWidth: 2,
                      borderLeftColor: colors.border,
                      paddingLeft: 14,
                      paddingVertical: 8,
                      gap: 4,
                    }}
                  >
                    <Body>{e.event_type.replaceAll("_", " ")}</Body>
                    <Caption>{formatDateTime(e.created_at)}</Caption>
                  </View>
                ))
              : null}
            <Button label="Move to Trash" variant="danger" onPress={trash} />
          </View>
        </View>
      ) : null}
      <Modal
        visible={!!preview}
        onRequestClose={() => setPreview(null)}
        transparent
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#000E",
            padding: 24,
            justifyContent: "center",
          }}
        >
          {preview ? (
            <Image
              source={{ uri: preview }}
              style={{ width: "100%", height: "75%" }}
              resizeMode="contain"
            />
          ) : null}
          <Button
            label="Close image"
            variant="secondary"
            onPress={() => setPreview(null)}
          />
        </View>
      </Modal>
    </Screen>
  );
}

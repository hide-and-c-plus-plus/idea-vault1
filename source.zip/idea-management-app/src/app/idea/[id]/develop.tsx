import React, { useEffect, useState } from "react";
import {
  Alert,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { H1, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { getIdea, updateIdea } from "@/db/repositories/ideas";
import { useDataChange } from "@/state/DataChangeContext";
import { colors, radius, spacing } from "@/theme/tokens";
const prompts = [
  ["summary", "What is the idea in one sentence?"],
  ["problem", "What problem or opportunity is it addressing?"],
  ["audience", "Who benefits?"],
  ["why_now", "Why might this work now?"],
  ["next_experiment", "What is the smallest test?"],
  ["risks", "What could kill it?"],
  ["done_definition", "What does success look like?"],
  ["next_action", "What is the next smallest action?"],
] as const;
export default function DevelopScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { bump } = useDataChange();
  const [values, setValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    getIdea(id).then((i) => {
      if (!i) return;
      const v: Record<string, string> = {};
      for (const [p] of prompts) v[p] = (i as any)[p] ?? "";
      setValues(v);
    });
  }, [id]);
  const save = async () => {
    setSaving(true);
    try {
      await updateIdea(id, values as any);
      bump();
      router.back();
    } catch (e) {
      Alert.alert("Could not save development", String(e));
    } finally {
      setSaving(false);
    }
  };
  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.icon}>
          <Text style={styles.glyph}>‹</Text>
        </Pressable>
        <H1>Develop idea</H1>
        <View style={styles.icon} />
      </View>
      <Secondary>
        Optional prompts, not a form wall. Skip anything that does not help.
      </Secondary>
      <View style={styles.list}>
        {prompts.map(([key, label]) => (
          <View key={key} style={styles.card}>
            <Secondary>{label}</Secondary>
            <TextInput
              multiline
              value={values[key] ?? ""}
              onChangeText={(text) => setValues((v) => ({ ...v, [key]: text }))}
              placeholder="Skip if it adds friction"
              placeholderTextColor={colors.textMuted}
              style={styles.input}
            />
          </View>
        ))}
      </View>
      <Button label="Save development" loading={saving} onPress={save} />
    </Screen>
  );
}
const styles = StyleSheet.create({
  header: {
    paddingTop: spacing.sm,
    minHeight: 60,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  icon: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  glyph: { color: colors.textPrimary, fontSize: 24 },
  list: { gap: spacing.md, marginVertical: spacing.xl },
  card: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.lg,
    padding: spacing.lg,
    gap: 8,
  },
  input: {
    minHeight: 76,
    color: colors.textPrimary,
    fontSize: 16,
    lineHeight: 24,
    textAlignVertical: "top",
  },
});

import React, { useState } from "react";
import { Alert, Pressable, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import { IdeaCard } from "@/components/idea/IdeaCard";
import {
  EmptyState,
  Field,
  IdeaPicker,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import { listIdeas, searchIdeas } from "@/db/repositories/ideas";
import {
  deleteProject,
  listProjects,
  saveProject,
  toggleProjectIdea,
} from "@/db/repositories/creative";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { colors } from "@/theme/tokens";
const swatches = [
  colors.accent,
  colors.success,
  colors.warning,
  colors.danger,
  "#79B6F2",
];
export default function ProjectsScreen() {
  const params = useLocalSearchParams<{ project?: string }>();
  const [selected, setSelected] = useState(params.project ?? ""),
    [creating, setCreating] = useState(false),
    [candidate, setCandidate] = useState("");
  const action = useAction();
  const form = useDraftForm("project_new", {
    name: "",
    intention: "",
    color: colors.accent as string,
  });
  const load = useLoad(async () => {
    const [projects, ideas, members] = await Promise.all([
      listProjects(),
      listIdeas({ limit: 500 }),
      selected
        ? searchIdeas("", { projectId: selected, includeArchived: true })
        : Promise.resolve([]),
    ]);
    return { projects, ideas, members };
  }, [selected]);
  const project = load.data?.projects.find((p) => p.id === selected);
  const memberIds = new Set(load.data?.members.map((i) => i.id));
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="COLLECT AROUND AN INTENTION"
        title={project?.name ?? "Project rooms"}
        subtitle={
          project?.intention ||
          "Give related sparks a shared place to become something."
        }
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {project ? (
        <View style={ui.stack}>
          <Button
            label="← All project rooms"
            variant="ghost"
            onPress={() => setSelected("")}
          />
          <Panel accent={project.color + "70"}>
            <IdeaPicker
              label="Bring an idea into this room"
              ideas={(load.data?.ideas ?? []).filter(
                (i) => !memberIds.has(i.id),
              )}
              value={candidate}
              onChange={setCandidate}
            />
            <Button
              label="Add to project"
              loading={action.busy}
              disabled={!candidate}
              onPress={() =>
                action.run(async () => {
                  await toggleProjectIdea(project.id, candidate);
                  setCandidate("");
                }, "Idea added to the room")
              }
            />
          </Panel>
          {load.data?.members.length === 0 ? (
            <EmptyState
              glyph="▱"
              title="This room is ready"
              body="Bring in existing ideas using the picker above. An idea can belong to more than one project."
            />
          ) : null}
          {load.data?.members.map((i) => (
            <View key={i.id} style={{ gap: 4 }}>
              <IdeaCard idea={i} />
              <Button
                label="Remove from this room"
                variant="ghost"
                disabled={action.busy}
                onPress={() =>
                  action.run(
                    () => toggleProjectIdea(project.id, i.id),
                    "Removed from room; idea kept in Vault",
                  )
                }
              />
            </View>
          ))}
          <Button
            label="Delete this project room"
            variant="danger"
            onPress={() =>
              Alert.alert(
                "Delete this room?",
                "Your ideas remain in the vault.",
                [
                  { text: "Keep it", style: "cancel" },
                  {
                    text: "Delete room",
                    style: "destructive",
                    onPress: () =>
                      action.run(async () => {
                        await deleteProject(project.id);
                        setSelected("");
                      }, "Project room removed"),
                  },
                ],
              )
            }
          />
        </View>
      ) : (
        <View style={ui.stack}>
          <Button
            label={creating ? "Close the new room" : "+ Create a project room"}
            variant="secondary"
            onPress={() => {
              form.resume();
              setCreating(!creating);
            }}
          />
          {creating && form.ready ? (
            <Panel>
              <Field
                label="Room name"
                value={form.value.name}
                onChangeText={(name) => form.setValue((v) => ({ ...v, name }))}
                placeholder="The next thing I want to make"
                maxLength={100}
              />
              <Field
                label="What holds these ideas together?"
                value={form.value.intention}
                onChangeText={(intention) =>
                  form.setValue((v) => ({ ...v, intention }))
                }
                multiline
                placeholder="An intention, a question, or a shared problem."
              />
              <View style={ui.wrap}>
                {swatches.map((color, index) => (
                  <Pressable
                    key={color}
                    accessibilityRole="button"
                    accessibilityLabel={`Project color ${index + 1}`}
                    accessibilityState={{
                      selected: color === form.value.color,
                    }}
                    onPress={() => form.setValue((v) => ({ ...v, color }))}
                    style={{
                      width: 48,
                      height: 48,
                      borderRadius: 24,
                      backgroundColor: color,
                      alignItems: "center",
                      justifyContent: "center",
                      borderWidth: color === form.value.color ? 3 : 0,
                      borderColor: colors.textPrimary,
                    }}
                  >
                    <Text style={{ color: "#111" }}>
                      {color === form.value.color ? "✓" : ""}
                    </Text>
                  </Pressable>
                ))}
              </View>
              <Button
                label="Open this room"
                loading={action.busy}
                disabled={!form.value.name.trim()}
                onPress={() =>
                  action.run(async () => {
                    const id = await saveProject(form.value);
                    await form.clear();
                    form.setValue({
                      name: "",
                      intention: "",
                      color: colors.accent,
                    });
                    setCreating(false);
                    setSelected(id);
                  }, "Room created")
                }
              />
            </Panel>
          ) : null}
          {load.data?.projects.map((p) => (
            <Pressable
              key={p.id}
              accessibilityRole="button"
              onPress={() => setSelected(p.id)}
            >
              <Panel accent={p.color + "70"}>
                <Caption style={{ color: p.color }}>
                  ▱ {p.idea_count} idea{p.idea_count === 1 ? "" : "s"}
                </Caption>
                <H2>{p.name}</H2>
                {p.intention ? <Secondary>{p.intention}</Secondary> : null}
                <Body style={{ color: p.color }}>Enter room →</Body>
              </Panel>
            </Pressable>
          ))}
          {load.data?.projects.length === 0 && !creating ? (
            <EmptyState
              glyph="▱"
              title="Make a room for a possibility"
              body="A final-year project, a collection of stories, or a problem you keep noticing. Start with an intention."
            />
          ) : null}
        </View>
      )}
    </Screen>
  );
}

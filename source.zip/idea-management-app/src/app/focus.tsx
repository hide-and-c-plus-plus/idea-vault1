import React, { useEffect, useRef, useState } from "react";
import { AppState, Text, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import {
  Field,
  IdeaPicker,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import { listIdeas } from "@/db/repositories/ideas";
import {
  currentFocus,
  finishFocus,
  focusHistory,
  saveFocusNotes,
  startFocus,
} from "@/db/repositories/creative";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { focusProgress, formatClock } from "@/domain/logic";
import { colors } from "@/theme/tokens";
export default function FocusScreen() {
  const params = useLocalSearchParams<{ idea?: string }>(),
    action = useAction();
  const form = useDraftForm(`focus_setup:${params.idea ?? "any"}`, {
    idea: params.idea ?? "",
    intention: "",
    minutes: 15,
  });
  const load = useLoad(async () => {
    const [session, history, ideas] = await Promise.all([
      currentFocus(),
      focusHistory(),
      listIdeas({ limit: 500 }),
    ]);
    return { session, history, ideas };
  });
  const [now, setNow] = useState(Date.now()),
    [notes, setNotes] = useState("");
  const notesRef = useRef(notes);
  notesRef.current = notes;
  const session = load.data?.session;
  useEffect(() => {
    setNotes(session?.notes ?? "");
  }, [session?.id]);
  useEffect(() => {
    if (!session) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    const sub = AppState.addEventListener("change", (state) => {
      if (state === "active") setNow(Date.now());
    });
    return () => {
      clearInterval(timer);
      sub.remove();
    };
  }, [session?.id]);
  useEffect(() => {
    if (!session) return;
    const id = session.id;
    const timer = setTimeout(
      () => saveFocusNotes(id, notes).catch(() => {}),
      450,
    );
    return () => clearTimeout(timer);
  }, [notes, session?.id]);
  useEffect(() => {
    if (!session) return;
    const id = session.id;
    return () => {
      void saveFocusNotes(id, notesRef.current).catch(() => {});
    };
  }, [session?.id]);
  const progress = session ? focusProgress(session, now) : null;
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="ONE SMALL PROMISE TO YOURSELF"
        title="The focus room"
        subtitle="You do not have to finish the whole idea. Just move it a little."
      />
      <LoadState
        loading={load.loading && !load.data}
        error={load.error}
        onRetry={load.reload}
      />
      {session && progress ? (
        <View style={ui.stack}>
          <Panel accent={colors.success + "70"}>
            <Caption style={{ color: colors.success }}>
              {progress.remaining
                ? "IN THIS MOMENT"
                : "A LITTLE SPACE, WELL SPENT"}
            </Caption>
            <H2>{session.intention}</H2>
            <Text
              accessibilityLiveRegion="none"
              style={{
                color: colors.textPrimary,
                fontSize: 72,
                fontWeight: "300",
                textAlign: "center",
                fontVariant: ["tabular-nums"],
                paddingVertical: 22,
              }}
            >
              {formatClock(progress.remaining)}
            </Text>
            <View
              style={{
                height: 5,
                borderRadius: 3,
                backgroundColor: colors.border,
                overflow: "hidden",
              }}
            >
              <View
                style={{
                  height: 5,
                  width: `${progress.fraction * 100}%`,
                  backgroundColor: colors.success,
                }}
              />
            </View>
            <Secondary>
              {progress.remaining
                ? "Your deadline is saved. You can leave this screen and come back."
                : "Time is up. Record what changed, then close the session."}
            </Secondary>
          </Panel>
          <Field
            label="What moved? What did you notice?"
            value={notes}
            onChangeText={setNotes}
            multiline
            placeholder="Fragments count. Your notes will join the idea’s timeline."
          />
          <Button
            label={
              progress.remaining
                ? "End early and keep my progress"
                : "Finish and keep my progress"
            }
            loading={action.busy}
            onPress={() =>
              action.run(async () => {
                await finishFocus(session.id, notes);
                setNotes("");
              }, "Session saved")
            }
          />
          {session.idea_id ? (
            <Button
              label="Open the idea"
              variant="ghost"
              onPress={() => router.push(`/idea/${session.idea_id}` as any)}
            />
          ) : null}
          <Caption>
            This is an elapsed-time session, not a background alarm. Early
            finishes record only the time that actually passed.
          </Caption>
        </View>
      ) : load.data && form.ready ? (
        <View style={ui.stack}>
          <IdeaPicker
            ideas={load.data.ideas}
            value={form.value.idea}
            onChange={(idea) => form.setValue((v) => ({ ...v, idea }))}
            optional
            label="Give this time to an idea"
          />
          <Field
            label="One small intention"
            value={form.value.intention}
            onChangeText={(intention) =>
              form.setValue((v) => ({ ...v, intention }))
            }
            placeholder="Sketch one screen. Test one assumption. Write one paragraph."
            multiline
          />
          <View style={ui.wrap}>
            {[5, 15, 25, 45].map((minutes) => (
              <Chip
                key={minutes}
                label={`${minutes} min`}
                selected={form.value.minutes === minutes}
                onPress={() => form.setValue((v) => ({ ...v, minutes }))}
              />
            ))}
          </View>
          <Button
            label="Begin a little focused time"
            loading={action.busy}
            disabled={!form.value.intention.trim()}
            onPress={() =>
              action.run(
                () =>
                  startFocus({
                    ideaId: form.value.idea || undefined,
                    intention: form.value.intention,
                    seconds: form.value.minutes * 60,
                  }),
                "Your session has started",
              )
            }
          />
        </View>
      ) : null}
      {load.data?.history.length ? (
        <View style={ui.section}>
          <H2>A trail of attention</H2>
          {load.data.history.map((s) => (
            <Panel key={s.id}>
              <Caption>
                {new Date(s.started_at).toLocaleDateString()} ·{" "}
                {formatClock(s.elapsed_seconds)} ·{" "}
                {s.status === "ended" ? "ended early" : "completed"}
              </Caption>
              <Body>{s.intention}</Body>
              {s.notes ? <Secondary>{s.notes}</Secondary> : null}
            </Panel>
          ))}
        </View>
      ) : null}
    </Screen>
  );
}

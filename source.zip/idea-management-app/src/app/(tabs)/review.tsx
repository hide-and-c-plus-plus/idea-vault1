import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { IdeaCard } from "@/components/idea/IdeaCard";
import {
  Field,
  LoadState,
  MiniStat,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import {
  listActiveIdeas,
  listInboxIdeas,
  markProcessed,
  updateIdea,
} from "@/db/repositories/ideas";
import {
  getInsights,
  reviewHistory,
  saveReview,
} from "@/db/repositories/creative";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { activityStreak, dayKeys } from "@/domain/logic";
import { colors } from "@/theme/tokens";
export default function ReviewScreen() {
  const [step, setStep] = useState(0),
    [selectedDay, setSelectedDay] = useState("");
  const action = useAction();
  const form = useDraftForm("weekly_reflection", {
    learned: "",
    release: "",
    next: "",
  });
  const load = useLoad(async () => {
    const [insights, inbox, active, history] = await Promise.all([
      getInsights(),
      listInboxIdeas(8),
      listActiveIdeas(),
      reviewHistory(),
    ]);
    return { insights, inbox, active, history };
  });
  const data = load.data;
  const milestones = data
    ? ([
        [
          "First spark",
          "Keep your first idea.",
          data.insights.stats.total >= 1,
        ],
        [
          "Unexpected company",
          "Create a connection.",
          data.insights.links >= 1,
        ],
        ["A small move", "Complete an action.", data.insights.actions >= 1],
        [
          "Learning over guessing",
          "Record an experiment outcome.",
          data.insights.experiments >= 1,
        ],
        [
          "Protected attention",
          "Finish a focus session.",
          data.insights.focusCount >= 1,
        ],
        [
          "Something in the world",
          "Move an idea to done.",
          data.insights.stats.done >= 1,
        ],
      ] as const)
    : [];
  return (
    <Screen>
      <PageHeader
        eyebrow="NOTICE WHAT IS GROWING"
        title="A little perspective."
        subtitle="Progress is more than collecting ideas. Sometimes it is making space."
      />
      <LoadState
        loading={load.loading && !data}
        error={load.error}
        onRetry={load.reload}
      />
      {data ? (
        <View style={ui.stack}>
          <Panel>
            <View style={ui.row}>
              <MiniStat label="ideas kept" value={data.insights.stats.total} />
              <MiniStat
                label="focus minutes"
                value={Math.floor(data.insights.focusSeconds / 60)}
                color={colors.success}
              />
              <MiniStat
                label="tests reflected on"
                value={data.insights.experiments}
                color={colors.warning}
              />
            </View>
            <Caption>YOUR LAST FOUR WEEKS</Caption>
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                gap: 7,
                maxWidth: 322,
              }}
            >
              {dayKeys(28).map((day) => {
                const count = data.insights.activity[day] ?? 0;
                return (
                  <Pressable
                    key={day}
                    accessibilityRole="button"
                    accessibilityLabel={`${day}: ${count} activities`}
                    onPress={() => setSelectedDay(day)}
                    style={{
                      width: 38,
                      height: 38,
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <View
                      style={{
                        width: 27,
                        height: 27,
                        borderRadius: 7,
                        backgroundColor: count
                          ? count > 5
                            ? colors.accent
                            : "#625187"
                          : colors.surfaceRaised,
                        borderWidth: day === selectedDay ? 2 : 1,
                        borderColor:
                          day === selectedDay
                            ? colors.textPrimary
                            : colors.border,
                      }}
                    />
                  </Pressable>
                );
              })}
            </View>
            <Secondary>
              {selectedDay
                ? `${selectedDay}: ${data.insights.activity[selectedDay] ?? 0} saved activities`
                : `${activityStreak(Object.keys(data.insights.activity))} recent consecutive active days. A quiet day never takes your progress away.`}
            </Secondary>
          </Panel>
          <View style={ui.section}>
            <H2>Your creative trail</H2>
            <View style={ui.wrap}>
              {milestones.map(([name, description, earned]) => (
                <View
                  key={name}
                  style={{
                    width: "47%",
                    minWidth: 135,
                    borderWidth: 1,
                    borderColor: earned ? colors.accent + "70" : colors.border,
                    borderRadius: 16,
                    padding: 14,
                    gap: 8,
                    backgroundColor: colors.surface,
                  }}
                >
                  <Text
                    style={{
                      color: earned ? colors.warning : colors.textMuted,
                      fontSize: 22,
                    }}
                  >
                    {earned ? "✦" : "◇"}
                  </Text>
                  <Body style={{ fontWeight: "600" }}>{name}</Body>
                  <Caption>{description}</Caption>
                  <Caption
                    style={{
                      color: earned ? colors.success : colors.textMuted,
                    }}
                  >
                    {earned ? "Reached" : "Still ahead"}
                  </Caption>
                </View>
              ))}
            </View>
          </View>
          <View style={ui.section}>
            <Panel accent={colors.accent + "60"}>
              <Caption>THE GENTLE RESET {step ? `· ${step} OF 3` : ""}</Caption>
              {step === 0 ? (
                <>
                  <H2>A review, not a reckoning.</H2>
                  <Secondary>
                    Sort a few sparks, protect your attention, and leave a note
                    for next week.
                  </Secondary>
                  <Button
                    label="Begin a gentle reset"
                    onPress={() => {
                      form.resume();
                      setStep(1);
                    }}
                  />
                </>
              ) : step === 1 ? (
                <>
                  <H2>Give a few sparks a home</H2>
                  {data.inbox.length ? (
                    data.inbox.map((i) => (
                      <View key={i.id} style={{ gap: 6 }}>
                        <IdeaCard idea={i} />
                        <Button
                          label="I have reviewed this"
                          variant="secondary"
                          disabled={action.busy}
                          onPress={() =>
                            action.run(
                              () => markProcessed(i.id),
                              "Idea reviewed",
                            )
                          }
                        />
                      </View>
                    ))
                  ) : (
                    <Secondary>Your inbox has room to breathe.</Secondary>
                  )}
                  <Button
                    label="Next · protect my attention"
                    onPress={() => setStep(2)}
                  />
                </>
              ) : step === 2 ? (
                <>
                  <H2>What deserves your attention?</H2>
                  <Secondary>
                    Keep the ideas you actually want to move. Parking the rest
                    is a decision, too.
                  </Secondary>
                  {data.active.length ? (
                    data.active.map((i) => (
                      <View key={i.id} style={{ gap: 6 }}>
                        <IdeaCard idea={i} />
                        <Button
                          label="Let this incubate"
                          variant="ghost"
                          disabled={action.busy}
                          onPress={() =>
                            action.run(
                              () => updateIdea(i.id, { stage: "parked" }),
                              "Idea parked safely",
                            )
                          }
                        />
                      </View>
                    ))
                  ) : (
                    <Secondary>
                      No active commitments. You can choose one from your vault
                      when ready.
                    </Secondary>
                  )}
                  <Button
                    label="Next · leave a reflection"
                    onPress={() => setStep(3)}
                  />
                </>
              ) : (
                <>
                  <H2>Keep the learning</H2>
                  <Field
                    label="Something I learned"
                    multiline
                    value={form.value.learned}
                    onChangeText={(learned) =>
                      form.setValue((v) => ({ ...v, learned }))
                    }
                  />
                  <Field
                    label="Something I can let go of"
                    multiline
                    value={form.value.release}
                    onChangeText={(release) =>
                      form.setValue((v) => ({ ...v, release }))
                    }
                  />
                  <Field
                    label="One small intention for next week"
                    multiline
                    value={form.value.next}
                    onChangeText={(next) =>
                      form.setValue((v) => ({ ...v, next }))
                    }
                  />
                  <Button
                    label="Keep this reflection"
                    loading={action.busy}
                    onPress={() =>
                      action.run(async () => {
                        await saveReview(
                          form.value.learned,
                          form.value.release,
                          form.value.next,
                        );
                        await form.clear();
                        form.setValue({ learned: "", release: "", next: "" });
                        setStep(0);
                      }, "Reflection saved. You can leave it here.")
                    }
                  />
                </>
              )}
              {step > 0 ? (
                <Button
                  label="Pause review"
                  variant="ghost"
                  onPress={() => setStep(0)}
                />
              ) : null}
            </Panel>
          </View>
          {data.history.length ? (
            <View style={ui.section}>
              <H2>Letters from your past weeks</H2>
              {data.history.map((r) => (
                <Panel key={r.id}>
                  <Caption>
                    {new Date(r.created_at).toLocaleDateString()}
                  </Caption>
                  {r.learned ? (
                    <>
                      <Caption>LEARNED</Caption>
                      <Body>{r.learned}</Body>
                    </>
                  ) : null}
                  {r.release_note ? (
                    <>
                      <Caption>RELEASED</Caption>
                      <Body>{r.release_note}</Body>
                    </>
                  ) : null}
                  {r.next_week ? (
                    <>
                      <Caption>NEXT INTENTION</Caption>
                      <Body>{r.next_week}</Body>
                    </>
                  ) : null}
                </Panel>
              ))}
            </View>
          ) : null}
        </View>
      ) : null}
    </Screen>
  );
}

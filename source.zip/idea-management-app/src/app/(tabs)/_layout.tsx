import React from "react";
import {
  Pressable,
  StyleSheet,
  Text,
  View,
  type ColorValue,
} from "react-native";
import { Tabs, router } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { colors } from "@/theme/tokens";
const icon =
  (glyph: string) =>
  ({ color }: { color: ColorValue }) => (
    <Text style={{ color, fontSize: 21 }}>{glyph}</Text>
  );
export default function TabsLayout() {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1 }}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarStyle: {
            backgroundColor: colors.bg,
            borderTopColor: colors.border,
            height: 64 + insets.bottom,
            paddingBottom: Math.max(insets.bottom, 8),
            paddingTop: 9,
          },
          tabBarActiveTintColor: colors.accent,
          tabBarInactiveTintColor: colors.textMuted,
          tabBarLabelStyle: { fontSize: 10, fontWeight: "600" },
        }}
      >
        <Tabs.Screen
          name="index"
          options={{ title: "Today", tabBarIcon: icon("⌂") }}
        />
        <Tabs.Screen
          name="library"
          options={{ title: "Vault", tabBarIcon: icon("▤") }}
        />
        <Tabs.Screen
          name="studio"
          options={{ title: "Studio", tabBarIcon: icon("✦") }}
        />
        <Tabs.Screen
          name="atlas"
          options={{ title: "Atlas", tabBarIcon: icon("◎") }}
        />
        <Tabs.Screen
          name="review"
          options={{ title: "Review", tabBarIcon: icon("◇") }}
        />
        <Tabs.Screen name="inbox" options={{ href: null }} />
      </Tabs>
      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Capture a new idea"
        onPress={() => router.push("/capture" as any)}
        style={({ pressed }) => [
          styles.capture,
          { bottom: 80 + insets.bottom },
          pressed && { opacity: 0.75 },
        ]}
      >
        <Text style={styles.plus}>+</Text>
        <Text style={styles.label}>Capture</Text>
      </Pressable>
    </View>
  );
}
const styles = StyleSheet.create({
  capture: {
    position: "absolute",
    right: 20,
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 18,
    height: 52,
    borderRadius: 26,
    backgroundColor: colors.accent,
    elevation: 5,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 5 },
  },
  plus: { color: "#15101F", fontSize: 24 },
  label: { color: "#15101F", fontWeight: "700", fontSize: 14 },
});

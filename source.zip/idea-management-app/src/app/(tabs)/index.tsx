import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { IdeaCard } from "@/components/idea/IdeaCard";
import {
  EmptyState,
  LoadState,
  MiniStat,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import { listActiveIdeas, listRecentIdeas } from "@/db/repositories/ideas";
import {
  getResurfacedIdeas,
  snoozeResurfaced,
} from "@/db/repositories/resurfacing";
import {
  currentFocus,
  getInsights,
  getSetting,
  setSetting,
} from "@/db/repositories/creative";
import { useAction, useLoad } from "@/hooks/useAsync";
import { DAILY_PROMPTS } from "@/domain/prompts";
import { dailyIndex } from "@/domain/logic";
import { colors } from "@/theme/tokens";
export default function HomeScreen() {
  const { data, loading, error, reload } = useLoad(async () => {
    const [active, recent, resurfaced, insights, focus, intro] =
      await Promise.all([
        listActiveIdeas(),
        listRecentIdeas(),
        getResurfacedIdeas(2),
        getInsights(),
        currentFocus(),
        getSetting("welcome_seen"),
      ]);
    return { active, recent, resurfaced, insights, focus, intro };
  });
  const action = useAction();
  const prompt = DAILY_PROMPTS[dailyIndex(DAILY_PROMPTS.length)]!;
  return (
    <Screen>
      <PageHeader
        eyebrow="IDEA VAULT / YOUR PRIVATE WORKSHOP"
        title="Room for possibility."
        subtitle={new Date().toLocaleDateString(undefined, {
          weekday: "long",
          day: "numeric",
          month: "long",
        })}
        right={
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Settings"
            onPress={() => router.push("/settings" as any)}
            style={styles.settings}
          >
            <Text style={{ color: colors.textSecondary, fontSize: 23 }}>⚙</Text>
          </Pressable>
        }
      />
      <View style={styles.hero}>
        <View style={styles.heroTop}>
          <Text style={styles.kicker}>CATCH IT BEFORE IT GOES</Text>
          <Text style={styles.spark}>✦</Text>
        </View>
        <Text style={styles.heroTitle}>
          {"A half-formed thought\nis a good beginning."}
        </Text>
        <Secondary style={{ color: "#CFC6F4" }}>
          Keep the rough edges. You can shape it later.
        </Secondary>
        <Button
          label="+  Capture a spark"
          onPress={() => router.push("/capture" as any)}
        />
        <View style={ui.row}>
          <Button
            label="Voice note"
            variant="ghost"
            onPress={() => router.push("/capture?mode=audio" as any)}
            style={{ flex: 1 }}
          />
          <Button
            label="Try a template"
            variant="ghost"
            onPress={() => router.push("/templates" as any)}
            style={{ flex: 1 }}
          />
        </View>
      </View>
      <LoadState loading={loading && !data} error={error} onRetry={reload} />
      {data ? (
        <>
          {!data.intro ? (
            <View style={ui.section}>
              <Panel>
                <H2>A vault that helps ideas grow</H2>
                <Secondary>
                  Capture in Vault. Play with possibilities in Studio. Find
                  relationships in Atlas. Make room for what matters in Review.
                </Secondary>
                <Button
                  label="Explore the creative tools"
                  onPress={() => router.push("/studio" as any)}
                />
                <Button
                  label="Got it"
                  variant="ghost"
                  loading={action.busy}
                  onPress={() =>
                    action.run(() => setSetting("welcome_seen", "true"))
                  }
                />
              </Panel>
            </View>
          ) : null}
          <View style={[ui.row, { marginTop: 28, paddingHorizontal: 4 }]}>
            <MiniStat label="ideas kept" value={data.insights.stats.total} />
            <MiniStat
              label="in motion"
              value={data.insights.stats.active}
              color={colors.success}
            />
            <MiniStat
              label="moves made"
              value={data.insights.actions}
              color={colors.warning}
            />
          </View>
          <View style={ui.section}>
            <View style={[ui.row, { justifyContent: "space-between" }]}>
              <H2>Your open loops</H2>
              <Caption>ONE SMALL STEP</Caption>
            </View>
            <Button
              label={`Inbox · ${data.insights.stats.inbox} to sort`}
              variant="secondary"
              onPress={() => router.push("/inbox" as any)}
            />
            {data.focus ? (
              <Button
                label="Resume your focus session →"
                onPress={() => router.push("/focus" as any)}
              />
            ) : null}
            {data.insights.readyCapsules > 0 ? (
              <Button
                label={`${data.insights.readyCapsules} time capsule${data.insights.readyCapsules === 1 ? "" : "s"} ready to open`}
                variant="secondary"
                onPress={() => router.push("/capsules" as any)}
              />
            ) : null}
            {data.active.map((i) => (
              <IdeaCard key={i.id} idea={i} />
            ))}
            {!data.active.length ? (
              <Secondary>
                No active ideas yet. Open a spark and put one small thing in
                motion.
              </Secondary>
            ) : null}
          </View>
          <View style={ui.section}>
            <Panel accent={colors.warning + "60"}>
              <Caption style={{ color: colors.warning }}>
                TODAY’S CREATIVE DETOUR
              </Caption>
              <H2>{prompt.title}</H2>
              <Body>{prompt.prompt}</Body>
              <Secondary>{prompt.hint}</Secondary>
              <Button
                label="Follow this thought →"
                variant="secondary"
                onPress={() =>
                  router.push({
                    pathname: "/capture",
                    params: {
                      seed: `${prompt.title}\n\n${prompt.prompt}\n\nMy thought:\n`,
                    },
                  } as any)
                }
              />
            </Panel>
          </View>
          <View style={ui.section}>
            <View style={ui.row}>
              <Button
                label="Projects"
                variant="secondary"
                onPress={() => router.push("/projects" as any)}
                style={{ flex: 1 }}
              />
              <Button
                label="Time capsules"
                variant="secondary"
                onPress={() => router.push("/capsules" as any)}
                style={{ flex: 1 }}
              />
            </View>
          </View>
          {data.resurfaced.length ? (
            <View style={ui.section}>
              <H2>Worth another look</H2>
              {data.resurfaced.map((i) => (
                <View key={i.id} style={{ gap: 8 }}>
                  <IdeaCard idea={i} reason={i.reason} />
                  <Button
                    label="Let this rest for a week"
                    variant="ghost"
                    disabled={action.busy}
                    onPress={() =>
                      action.run(
                        () => snoozeResurfaced(i.id, 7),
                        "Snoozed for a week",
                      )
                    }
                  />
                </View>
              ))}
            </View>
          ) : null}
          <View style={ui.section}>
            <H2>Recently in your orbit</H2>
            {data.recent.length ? (
              data.recent.map((i) => <IdeaCard key={i.id} idea={i} />)
            ) : (
              <EmptyState
                title="Your first spark belongs here"
                body="A question, a half-built project, an odd observation. It does not need to be impressive."
                action={
                  <Button
                    label="Capture the first one"
                    onPress={() => router.push("/capture" as any)}
                  />
                }
              />
            )}
          </View>
        </>
      ) : null}
    </Screen>
  );
}
const styles = StyleSheet.create({
  settings: {
    width: 48,
    height: 48,
    alignItems: "center",
    justifyContent: "center",
  },
  hero: {
    backgroundColor: "#27203D",
    borderColor: "#55467B",
    borderWidth: 1,
    borderRadius: 24,
    padding: 22,
    gap: 16,
  },
  heroTop: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  kicker: {
    color: "#CBB9FF",
    fontSize: 10,
    fontWeight: "700",
    letterSpacing: 1.8,
  },
  spark: { color: colors.accent, fontSize: 34 },
  heroTitle: {
    fontSize: 29,
    lineHeight: 37,
    color: colors.textPrimary,
    fontWeight: "600",
    letterSpacing: -0.5,
  },
});

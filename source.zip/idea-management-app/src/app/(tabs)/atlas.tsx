import React, { useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import {
  EmptyState,
  IdeaPicker,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import { listGraph } from "@/db/repositories/creative";
import { addIdeaLink } from "@/db/repositories/links";
import { useAction, useLoad } from "@/hooks/useAsync";
import { relatedIdeas, ringPoints, shuffle } from "@/domain/logic";
import { colors } from "@/theme/tokens";
export default function AtlasScreen() {
  const load = useLoad(listGraph),
    action = useAction();
  const [selection, setSelection] = useState(""),
    [width, setWidth] = useState(320);
  const data = load.data;
  const focus = data?.ideas.find((i) => i.id === selection) ?? data?.ideas[0];
  const connections =
    data?.edges.filter(
      (e) => e.source_idea_id === focus?.id || e.target_idea_id === focus?.id,
    ) ?? [];
  const relatedIds = new Set(
    connections.map((e) =>
      e.source_idea_id === focus?.id ? e.target_idea_id : e.source_idea_id,
    ),
  );
  const orbit = (data?.ideas.filter((i) => relatedIds.has(i.id)) ?? []).slice(
    0,
    7,
  );
  const nodes = focus ? [focus, ...orbit] : [];
  const points = [
    { x: width / 2, y: 190 },
    ...ringPoints(orbit.length, width, 380),
  ];
  // A single satellite sits above the focal node rather than on top of it.
  if (orbit.length === 1) points[1] = { x: width / 2, y: 65 };
  const suggestions = useMemo(
    () =>
      focus && data
        ? relatedIdeas(focus, data.ideas).filter(
            (r) => !relatedIds.has(r.idea.id),
          )
        : [],
    [data, focus?.id],
  );
  return (
    <Screen>
      <PageHeader
        eyebrow="THE ATLAS"
        title="Nothing grows alone."
        subtitle="See the threads between your ideas. Follow one somewhere new."
      />
      <LoadState
        loading={load.loading && !data}
        error={load.error}
        onRetry={load.reload}
      />
      {data && !data.ideas.length ? (
        <EmptyState
          glyph="◎"
          title="Your constellation starts with a spark"
          body="Capture a few ideas. Connect them manually or bring two together in the Collision lab."
          action={
            <Button
              label="Capture an idea"
              onPress={() => router.push("/capture" as any)}
            />
          }
        />
      ) : null}
      {focus && data ? (
        <View style={ui.stack}>
          <IdeaPicker
            label="Center your map on"
            ideas={data.ideas}
            value={focus.id}
            onChange={setSelection}
          />
          <View
            style={styles.map}
            onLayout={(e) => setWidth(e.nativeEvent.layout.width)}
            accessibilityLabel="Map of explicit idea connections"
          >
            <View
              pointerEvents="none"
              style={[
                styles.ring,
                { left: width / 2 - 100, top: 90, width: 200, height: 200 },
              ]}
            />
            <View
              pointerEvents="none"
              style={[
                styles.ring,
                { left: width / 2 - 50, top: 140, width: 100, height: 100 },
              ]}
            />
            {data.edges
              .filter(
                (e) =>
                  nodes.some((n) => n.id === e.source_idea_id) &&
                  nodes.some((n) => n.id === e.target_idea_id),
              )
              .map((e) => {
                const a =
                    points[nodes.findIndex((n) => n.id === e.source_idea_id)]!,
                  b =
                    points[nodes.findIndex((n) => n.id === e.target_idea_id)]!;
                const dx = b.x - a.x,
                  dy = b.y - a.y,
                  length = Math.hypot(dx, dy);
                return (
                  <View
                    key={e.id}
                    pointerEvents="none"
                    style={{
                      position: "absolute",
                      left: (a.x + b.x) / 2 - length / 2,
                      top: (a.y + b.y) / 2,
                      height: 1,
                      width: length,
                      backgroundColor: colors.accent + "70",
                      transform: [{ rotate: `${Math.atan2(dy, dx)}rad` }],
                    }}
                  />
                );
              })}
            {nodes.map((node, index) => (
              <Pressable
                key={node.id}
                accessibilityRole="button"
                accessibilityLabel={`${node.title}. ${index === 0 ? "Open idea" : "Center map on this idea"}`}
                onPress={() =>
                  index === 0
                    ? router.push(`/idea/${node.id}` as any)
                    : setSelection(node.id)
                }
                style={[
                  styles.node,
                  { left: points[index]!.x - 41, top: points[index]!.y - 41 },
                  index === 0 && styles.center,
                ]}
              >
                <Text
                  style={[
                    styles.nodeIcon,
                    index === 0 && { color: colors.accent },
                  ]}
                >
                  {index === 0 ? "✦" : "◦"}
                </Text>
                <Text numberOfLines={2} style={styles.nodeLabel}>
                  {node.title || "Untitled"}
                </Text>
              </Pressable>
            ))}
          </View>
          <Caption>
            {connections.length} explicit connection
            {connections.length === 1 ? "" : "s"}. Map shows up to seven
            neighbors; tap a satellite to explore it.
          </Caption>
          <Panel>
            <Caption style={{ color: colors.accent }}>IN FOCUS</Caption>
            <H2>{focus.title}</H2>
            <Secondary numberOfLines={3}>
              {focus.summary || focus.snippet || "A thought waiting to unfold."}
            </Secondary>
            <View style={ui.row}>
              <Button
                label="Open idea"
                onPress={() => router.push(`/idea/${focus.id}` as any)}
                style={{ flex: 1 }}
              />
              <Button
                label="Wander ↻"
                variant="secondary"
                disabled={data.ideas.length < 2}
                onPress={() =>
                  setSelection(
                    shuffle(data.ideas.filter((i) => i.id !== focus.id))[0]!.id,
                  )
                }
                style={{ flex: 1 }}
              />
            </View>
            <Button
              label="Link another idea"
              variant="ghost"
              onPress={() => router.push(`/idea/${focus.id}/link` as any)}
            />
          </Panel>
          <View style={ui.section}>
            <H2>The threads</H2>
            {connections.length ? (
              connections.map((e) => {
                const other = data.ideas.find(
                  (i) =>
                    i.id ===
                    (e.source_idea_id === focus.id
                      ? e.target_idea_id
                      : e.source_idea_id),
                );
                return other ? (
                  <Pressable
                    key={e.id}
                    accessibilityRole="button"
                    onPress={() => router.push(`/idea/${other.id}` as any)}
                    style={ui.panel}
                  >
                    <Caption>
                      {e.source_idea_id === focus.id ? "→" : "←"}{" "}
                      {e.link_type.replaceAll("_", " ")}
                    </Caption>
                    <Body>{other.title}</Body>
                  </Pressable>
                ) : null;
              })
            ) : (
              <Secondary>
                No links yet. Combine ideas in the lab or add a connection
                yourself.
              </Secondary>
            )}
          </View>
          <View style={ui.section}>
            <H2>Possible neighbors</H2>
            <Secondary>
              Shared words offer a starting point, not proof that ideas belong
              together. Suggestions scan up to 500 recent ideas.
            </Secondary>
            {suggestions.length ? (
              suggestions.map(({ idea, words }) => (
                <Panel key={idea.id}>
                  <Body>{idea.title}</Body>
                  <Caption>
                    Shared words: {words.slice(0, 5).join(", ")}
                  </Caption>
                  <View style={ui.row}>
                    <Button
                      label="Read"
                      variant="ghost"
                      onPress={() => router.push(`/idea/${idea.id}` as any)}
                      style={{ flex: 1 }}
                    />
                    <Button
                      label="Connect"
                      variant="secondary"
                      disabled={action.busy}
                      onPress={() =>
                        action.run(
                          () => addIdeaLink(focus.id, idea.id, "related_to"),
                          "Connection added",
                        )
                      }
                      style={{ flex: 1 }}
                    />
                  </View>
                </Panel>
              ))
            ) : (
              <Secondary>
                No unlinked word matches yet. An unexpected connection can still
                be worth making.
              </Secondary>
            )}
          </View>
        </View>
      ) : null}
    </Screen>
  );
}
const styles = StyleSheet.create({
  map: {
    height: 380,
    backgroundColor: "#121520",
    borderRadius: 24,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
  },
  ring: {
    position: "absolute",
    borderWidth: 1,
    borderColor: "#292D40",
    borderRadius: 999,
  },
  node: {
    position: "absolute",
    width: 82,
    height: 82,
    borderRadius: 41,
    backgroundColor: colors.surfaceRaised,
    borderWidth: 1,
    borderColor: colors.border,
    alignItems: "center",
    justifyContent: "center",
    padding: 8,
    gap: 2,
  },
  center: {
    backgroundColor: "#2B2443",
    borderColor: colors.accent,
    borderWidth: 2,
  },
  nodeIcon: { color: colors.textSecondary, fontSize: 22 },
  nodeLabel: {
    fontSize: 10,
    lineHeight: 13,
    color: colors.textPrimary,
    textAlign: "center",
  },
});

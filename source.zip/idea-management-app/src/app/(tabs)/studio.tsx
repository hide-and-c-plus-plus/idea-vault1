import React from "react";
import { Text, View } from "react-native";
import { router } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { PageHeader, Panel, ToolTile, ui } from "@/components/studio/StudioUI";
import { colors } from "@/theme/tokens";
const tools = [
  [
    "⇄",
    "Collision lab",
    "Let two of your ideas meet. Save their unexpected offspring.",
    "collision",
    colors.accent,
  ],
  [
    "✧",
    "Remix deck",
    "Seven transformations to find another version of an idea.",
    "remix",
    colors.warning,
  ],
  [
    "◉",
    "Council of perspectives",
    "Try the dreamer, skeptic, maker, and four other lenses.",
    "council",
    colors.success,
  ],
  [
    "↯",
    "Constraint roulette",
    "A useful restriction can unlock a stranger solution.",
    "constraints",
    colors.danger,
  ],
  [
    "⌕",
    "Assumption ladder",
    "Separate a belief from evidence and design a way to learn.",
    "assumptions",
    colors.accent,
  ],
  [
    "↗",
    "One-page pitch",
    "Turn scattered notes into a clear, editable brief to share.",
    "pitch",
    colors.warning,
  ],
] as const;
export default function StudioScreen() {
  return (
    <Screen>
      <PageHeader
        eyebrow="THE CREATIVE STUDIO"
        title="Make room for strange."
        subtitle="Small exercises. Unexpected connections. Your own thinking."
      />
      <Panel accent={colors.accent + "70"}>
        <View style={ui.row}>
          <Text style={{ color: colors.accent, fontSize: 40 }}>✦</Text>
          <View style={{ flex: 1, gap: 6 }}>
            <H2>Play before you polish.</H2>
            <Secondary>
              These tools ask better questions. You supply the surprising
              answers.
            </Secondary>
          </View>
        </View>
        <Button
          label="Surprise me →"
          onPress={() =>
            router.push(
              `/lab?tool=${tools[Math.floor(Math.random() * tools.length)]![3]}` as any,
            )
          }
        />
      </Panel>
      <View style={ui.section}>
        <Caption>CHANGE THE SHAPE OF A THOUGHT</Caption>
        {tools.map(([glyph, title, description, tool, color]) => (
          <ToolTile
            key={tool}
            glyph={glyph}
            title={title}
            description={description}
            color={color}
            onPress={() => router.push(`/lab?tool=${tool}` as any)}
          />
        ))}
      </View>
      <View style={ui.section}>
        <Caption>GIVE IT SOMEWHERE TO GO</Caption>
        <ToolTile
          glyph="◷"
          title="Focus room"
          description="One idea. One intention. A little protected time."
          onPress={() => router.push("/focus" as any)}
          color={colors.success}
        />
        <ToolTile
          glyph="⚗"
          title="Experiment bench"
          description="Test an assumption and preserve what actually happened."
          onPress={() => router.push("/experiments" as any)}
        />
        <ToolTile
          glyph="⌁"
          title="Time capsules"
          description="Send a thought to a future version of yourself."
          onPress={() => router.push("/capsules" as any)}
          color={colors.warning}
        />
        <ToolTile
          glyph="▱"
          title="Project rooms"
          description="Gather related ideas around a shared intention."
          onPress={() => router.push("/projects" as any)}
        />
        <ToolTile
          glyph="▧"
          title="Capture starters"
          description="Twelve structures for stories, research, products, and life."
          onPress={() => router.push("/templates" as any)}
          color={colors.success}
        />
      </View>
      <View style={ui.section}>
        <Secondary>
          Everything you make here stays in your vault. New branches remember
          where they came from.
        </Secondary>
      </View>
    </Screen>
  );
}

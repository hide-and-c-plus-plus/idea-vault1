import React, { useEffect, useState } from "react";
import { Alert, AppState, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Screen } from "@/components/ui/Screen";
import { Body, Caption, H2, Secondary } from "@/components/ui/Typography";
import { Button } from "@/components/ui/Button";
import { Chip } from "@/components/ui/Chip";
import {
  EmptyState,
  Field,
  LoadState,
  PageHeader,
  Panel,
  ui,
} from "@/components/studio/StudioUI";
import {
  createCapsule,
  deleteCapsule,
  listCapsules,
  openCapsule,
} from "@/db/repositories/creative";
import { useAction, useDraftForm, useLoad } from "@/hooks/useAsync";
import { colors } from "@/theme/tokens";
export default function CapsuleScreen() {
  const params = useLocalSearchParams<{ idea?: string }>(),
    action = useAction();
  const load = useLoad(listCapsules);
  const [writing, setWriting] = useState(!!params.idea),
    [openId, setOpenId] = useState(""),
    [now, setNow] = useState(Date.now());
  const form = useDraftForm(`capsule:${params.idea ?? "free"}`, {
    title: "",
    body: "",
    days: 7,
  });
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 30000);
    const sub = AppState.addEventListener("change", (s) => {
      if (s === "active") {
        setNow(Date.now());
        load.reload();
      }
    });
    return () => {
      clearInterval(timer);
      sub.remove();
    };
  }, []);
  useEffect(() => {
    if (load.data?.some((c) => !c.body && c.unlock_at <= now)) load.reload();
  }, [now]);
  return (
    <Screen>
      <PageHeader
        back
        eyebrow="A LETTER ACROSS TIME"
        title="Time capsules"
        subtitle="Let an idea rest. Meet it again with different eyes."
      />
      <Button
        label={writing ? "Close the writing desk" : "+ Write to future me"}
        variant="secondary"
        onPress={() => {
          form.resume();
          setWriting(!writing);
        }}
      />
      {writing && form.ready ? (
        <View style={ui.section}>
          <Panel accent={colors.warning + "70"}>
            <Field
              label="A label for the envelope"
              value={form.value.title}
              onChangeText={(title) => form.setValue((v) => ({ ...v, title }))}
              placeholder="Open when you need a little courage"
              maxLength={180}
            />
            <Field
              label="Dear future me…"
              value={form.value.body}
              onChangeText={(body) => form.setValue((v) => ({ ...v, body }))}
              multiline
              placeholder="What do you hope you tried? What should you remember?"
            />
            <Caption>Open after</Caption>
            <View style={ui.wrap}>
              {[1, 7, 30, 90].map((days) => (
                <Chip
                  key={days}
                  label={`${days} day${days === 1 ? "" : "s"}`}
                  selected={form.value.days === days}
                  onPress={() => form.setValue((v) => ({ ...v, days }))}
                />
              ))}
            </View>
            <Button
              label="Seal this capsule"
              loading={action.busy}
              disabled={!form.value.title.trim() || !form.value.body.trim()}
              onPress={() =>
                action.run(async () => {
                  const date = new Date();
                  date.setDate(date.getDate() + form.value.days);
                  await createCapsule({
                    ideaId: params.idea,
                    title: form.value.title,
                    body: form.value.body,
                    unlockAt: date.getTime(),
                  });
                  await form.clear();
                  setWriting(false);
                  form.setValue({ title: "", body: "", days: 7 });
                }, "Capsule sealed")
              }
            />
            <Secondary>
              It will appear on Today when ready. This is a gentle time lock,
              not encryption; exports include the full letter.
            </Secondary>
          </Panel>
        </View>
      ) : null}
      <View style={ui.section}>
        <LoadState
          loading={load.loading && !load.data}
          error={load.error}
          onRetry={load.reload}
        />
        {load.data?.length === 0 ? (
          <EmptyState
            glyph="⌁"
            title="Something for your future self"
            body="Write a question, a hope, or the reason an idea matters. Give it a little time."
          />
        ) : null}
        {load.data?.map((c) => {
          const unlocked = c.unlock_at <= now,
            expanded = openId === c.id;
          return (
            <Panel
              key={c.id}
              accent={unlocked ? colors.warning + "60" : undefined}
            >
              <Caption
                style={{ color: unlocked ? colors.warning : colors.textMuted }}
              >
                {unlocked
                  ? c.opened_at
                    ? "OPENED"
                    : "READY TO OPEN"
                  : "INCUBATING"}{" "}
                · {new Date(c.unlock_at).toLocaleString()}
              </Caption>
              <H2>{c.title}</H2>
              {expanded && unlocked ? (
                <>
                  <Body selectable>{c.body}</Body>
                  {c.idea_id ? (
                    <Button
                      label="Revisit the original idea"
                      variant="ghost"
                      onPress={() => router.push(`/idea/${c.idea_id}` as any)}
                    />
                  ) : null}
                </>
              ) : null}
              <Button
                label={
                  !unlocked
                    ? "Still sealed"
                    : expanded
                      ? "Fold the letter"
                      : "Open the letter"
                }
                disabled={!unlocked || action.busy}
                variant="secondary"
                onPress={() => {
                  if (expanded) setOpenId("");
                  else
                    action.run(async () => {
                      await openCapsule(c.id);
                      setOpenId(c.id);
                    });
                }}
              />
              <Button
                label="Discard capsule"
                variant="ghost"
                onPress={() =>
                  Alert.alert(
                    "Discard this letter?",
                    "This deletes the letter permanently.",
                    [
                      { text: "Keep it", style: "cancel" },
                      {
                        text: "Discard",
                        style: "destructive",
                        onPress: () =>
                          action.run(
                            () => deleteCapsule(c.id),
                            "Capsule discarded",
                          ),
                      },
                    ],
                  )
                }
              />
            </Panel>
          );
        })}
      </View>
    </Screen>
  );
}

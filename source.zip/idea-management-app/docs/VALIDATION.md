# Validation record

Validated on 8 October 2026 using Node.js 24.19.0. Android is the intended native target. The screenshots are from the actual app's browser build, not design mockups.

## Completed checks

| Check                                   | Result                                                               |
| --------------------------------------- | -------------------------------------------------------------------- |
| TypeScript strict typecheck             | Passed                                                               |
| Domain and real-SQLite repository tests | 35 passed, none failed                                               |
| Expo Android JavaScript / Hermes bundle | Built successfully                                                   |
| Expo web production bundle              | Built successfully                                                   |
| Expo prebuild configuration resolution  | Passed                                                               |
| Browser workflow walkthrough            | 13 flows passed; no captured JavaScript errors                       |
| Visual inspection                       | Mobile Today, mobile Studio, mobile Atlas, and wide Studio inspected |

The Android bundle check compiles the JavaScript and assets. It does not produce or install a complete native APK. Native device functionality still needs the device pass below.

## Browser workflows exercised

- Capture a text idea, use Save + New, capture another, and return to Today.
- Create a collision offspring from two real captures and open its detail screen.
- Create and complete a checklist task.
- Add an idea to the shortlist.
- Render the saved parent connections in Atlas.
- Start focus, reload, recover the session, and record an early finish with notes.
- Design an experiment, record observations, and save a challenged outcome.
- Seal a future time capsule and verify that its open control is disabled.
- Create a project room and add an existing idea.
- Search the vault and persist a named saved view.
- Complete the guided review and read the saved reflection.
- Return to an idea after full navigation and verify task completion persisted.
- Render the Studio at desktop width as well as a narrow mobile viewport.

The browser pass found and resolved missing FTS5 support in Expo's web SQLite build, native-only notification/share-in hooks during browser startup, and missing web checkbox state attributes. Native FTS5 remains enabled. On a database without FTS5, the app uses a plain text index and parameter-bound substring matching; relevance ranking and native FTS highlighting are not promised in that fallback.

## Automated test coverage

The tests exercise production repositories against Node's real SQLite engine, with foreign keys and FTS5. Device filesystem, notification, and share I/O are substituted only inside the test loader. The app itself uses Expo APIs.

Tests cover a populated original v1 database upgrading to v2; idempotent migrations; atomic captures with attachments; recovered draft removal on success and preservation on simulated failure; FTS and literal fallback search; Unicode combining marks; collision provenance and invalid-parent rollback; transaction recovery and concurrent writes; tasks; experiment evidence; capsule timing; focus uniqueness, actual elapsed seconds, and idempotent finish; project deletion without idea deletion; shortlist/energy filters; trash/link visibility; reminder cancellation; foreign-key cleanup; saved views; reviews; opt-in sample data; complete Studio exports; and pure date/layout/word-matching helpers.

Run them with:

```bash
npm ci
npm run typecheck
npm test
```

## Required native-device checks before release

- Build and install on Android with the same package/signing identity if upgrading existing data.
- Exercise camera, microphone, media picker, file picker, and notification permissions, including denial and revocation.
- Record audio, background the app, stop, replay, and restart the app.
- Test share-in for text, URLs, an image, audio, and a file from other Android apps.
- Test share-out and save the exported archive outside the app's private directory.
- Tap a notification from both a cold and a running app, and delete an idea that has a scheduled reminder.
- Recover capture drafts after Android back navigation and process death.
- Inspect keyboard behavior, safe areas, larger system text, TalkBack, and long idea titles on a physical phone.

Those hardware and operating-system interactions were not verified in an emulator or on a physical Android device here. No Android APK or release-readiness certification is implied.

## Preview files

- `screenshots/studio-mobile.png`
- `screenshots/atlas-mobile.png`
- `screenshots/studio-wide.png`

Screenshots use small test ideas. That browser test database is not included in the source archive. The shipped app starts with an empty vault unless you are upgrading an existing installation or explicitly add playground examples.

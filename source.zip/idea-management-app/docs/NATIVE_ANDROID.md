# Android development and release notes

Keep `com.localfirst.ideavault` and the original signing identity to upgrade an existing installation in place. The database name remains `idea-vault.db`; migration 2 adds Studio columns and tables without deleting original captures.

## Development build

Use `npm ci`, `npm run prebuild`, then `npm run android`. The app includes `expo-dev-client`; use the installed development build when testing native capabilities. The Android SDK/JDK and emulator or a USB-debugging device must be configured locally.

The app config retains microphone and notification permissions, background recording configuration, SQLite FTS, the `ideavault` URL scheme, and the Expo Sharing incoming-share plugin. Native configuration changes need a rebuilt app, not only a JavaScript reload.

## Required device pass before release

Exercise denied/granted/revoked microphone, camera, photo and notification permissions; background recording; audio playback after restart; image/file import; native share-in; share-out; notification deep links; soft delete of reminded ideas; and restore from Trash. Verify capture draft recovery after Android back navigation, process death, and a second incoming share. Check the keyboard and navigation bars on a small physical device.

The source does not add authentication, a remote server, or app-level encryption. App shortcuts, widgets, SQLCipher, a genuine key lifecycle, biometric access control, and encrypted media require their own native implementation and migration work. There are no placeholder controls claiming those capabilities.

Review the generated Android target settings and current distribution requirements when preparing a release. EAS profiles are supplied for convenience but are not connected to an account or signing credentials in this archive.

# The creative playbook

The guiding idea is that a useful idea app should help you do more than keep a list. It should help you notice, play, connect, test, make, and reflect. The Studio edition implements that loop without making your private thoughts depend on an online service.

## Catch a thought before deciding what it is

| Feature                   | Where                         | What it does                                                                                                                                                                                 |
| ------------------------- | ----------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Quick capture             | Capture button                | Saves text, voice, camera/image, or file captures; original captures remain distinguishable from later notes.                                                                                |
| Recoverable capture draft | Capture                       | Keeps the text and media references; explicit Close flushes the latest draft. Save + New starts a fresh capture.                                                                             |
| Twelve capture starters   | Studio → Capture starters     | Free thought, friction log, product seed, research question, story seed, learning lab, field note, impossible idea, life experiment, future-self letter, borrowed pattern, decision journal. |
| Daily creative detour     | Today                         | Rotates through 21 authored invitations, using the local calendar date. Open one directly in Capture.                                                                                        |
| Text/Markdown import      | Settings                      | Turns a chosen text note into a new idea while preserving its contents as the original capture.                                                                                              |
| Voice and inbound sharing | Capture / Android share sheet | Preserves the existing native media workflow, with app-private copies for imported media.                                                                                                    |

A starter is not a required form. Leave questions unanswered if they are not useful. If you have a recovered capture draft, opening a new starter appends it under a separator instead of overwriting your thought.

## Make the familiar strange

| Feature                 | What you do                                                                                                      | What is saved                                                                             |
| ----------------------- | ---------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| Collision lab           | Choose two ideas or shuffle an unexpected pair. Try one of eight bridge prompts and write the offspring.         | A new idea with explicit `combines_with` links to both parents, saved in one transaction. |
| Remix deck              | Try Substitute, Combine, Adapt, Magnify/shrink, Another use, Eliminate, or Reverse.                              | A prompt and your response on the source timeline, or a new linked branch.                |
| Council of perspectives | View an idea through the dreamer, first user, kind skeptic, maker, caretaker, editor, or future-you lens.        | Your own written response, with the lens and prompt preserved.                            |
| Constraint roulette     | Cycle through 24 restrictions, optionally applied to an existing idea.                                           | A new idea, linked to its source when one was selected.                                   |
| Assumption ladder       | Separate an assumption from what you observed and a test that could challenge it.                                | A structured thought or branch.                                                           |
| One-page pitch          | Assemble your existing development fields into an editable brief, complete missing parts, then share or keep it. | A timeline note or branch; sharing opens the device share sheet.                          |
| Surprise me             | Let the Studio pick one of its six creative tools.                                                               | Nothing is created until you write and save.                                              |

These are thinking aids, not simulated AI agents. The council does not fabricate feedback, the pitch builder does not invent market facts, and the collision lab does not pretend an authored prompt is a machine-generated discovery.

## Follow the connections

**Atlas** draws a selected idea with up to seven explicitly linked neighbors. Lines represent saved connections. Tap a satellite to recenter the map; tap the central idea to open it. The list below provides the relationship labels and equivalent navigation without requiring use of the diagram.

**Possible neighbors** compares meaningful words from titles, summaries, and original text snippets. Suggestions explain which words overlap. They do not silently add connections. This is deliberately inspectable lexical matching, not semantic search or a similarity probability.

**Wander** chooses another idea from the loaded vault. Use it when you want a detour through your own thinking rather than a feed from somewhere else.

**Backlinks and lineage** are visible in idea detail. A branch remembers its source. Removing a connection does not remove either idea, and trashed ideas disappear from active maps and backlinks.

## Protect a little attention

**Focus room:** choose an idea, write one intention, and pick a short session. The session and deadline are stored in SQLite. Navigating away or restarting the app does not reset the session. The countdown uses the deadline rather than assuming every JavaScript interval ran in the background. End early when appropriate; only elapsed seconds are kept. Notes attach to the linked idea when you finish. A second running session cannot be started by a duplicate tap.

**Tiny next moves:** every idea has a checklist. Add a concrete action, mark it complete, reopen it, or remove it. Completed actions contribute to the creative trail. Making one small thing is enough; the app does not award a made-up productivity score.

**Energy compass:** label an idea as gentle, steady, or deep. Filter the vault to match the attention you currently have. These labels are your judgment, not a psychological assessment.

**Shortlist:** star an idea to give it prominence and make it accessible through a dedicated Vault filter.

## Learn from reality

**Experiment bench** keeps four things separate: your prediction, the test, the success signal chosen beforehand, and what actually happened. Start with an untested or running experiment, then record an outcome as supported, challenged, or inconclusive. An outcome needs an observation. The label is your assessment of evidence, not statistical significance or scientific proof.

**Development brief** preserves the existing structured fields: summary, problem, audience, why now, smallest test, risks, success definition, and next action. These feed the pitch builder and remain searchable.

**Later thoughts** add dated reflections without rewriting the original capture. Actual image previews and file sharing make attachments useful evidence rather than just filenames. **Idea history** exposes the last 40 recorded events, including stages, tasks, experiments, branches, and focus work.

## Give an idea somewhere to grow

**Project rooms** gather ideas around an intention. An idea can belong to multiple rooms. Add or remove membership in a project screen or in the idea's organization panel. Deleting a room preserves the ideas.

**Stage board** arranges the current Vault results into Sparks, Exploring, Promising, In motion, Incubating, Realized, Released, and optionally Archived. A card has an explicit move control; the board does not require fragile drag gestures on a small screen.

**Saved views** preserve a search and its filters under a name. Useful examples: “Gentle learning ideas,” “Shortlisted stories,” or “Product sparks for now.” Saved date filters are fixed cutoff dates, not rolling subscriptions.

**Time capsules** seal a letter until a chosen future date. Capsules can stand alone or remain associated with an idea. When due, Today shows a reminder to open them. Opening records the date; the letter remains available for rereading. Capsules do not schedule system notifications and are not encrypted envelopes.

## Notice what changed

**Review** includes a local activity calendar, total recorded focus time, completed experiment outcomes, and six milestones derived from actual saved activity. Tap a calendar square to inspect the activity count. The calendar counts recorded idea events and review reflections; it does not claim to measure hours of thinking or passive app opens.

A **gentle reset** moves through inbox attention, active commitments, and a written reflection. Save what you learned, what you can release, and one next intention. Previous reviews remain readable. You can pause without losing the reflection draft.

The **creative trail** recognizes a first spark, a connection, a completed action, an experiment outcome, recorded focus, and a realized idea. There are no purchasable points or leaderboards. Days with no activity do not remove saved work.

## A few ways to combine the tools

### For a final-year project

Capture a research question. Use the assumption ladder to identify what you do not know. Record a tiny experiment and its success signal. Put implementation notes in a project room. Turn the next unknown into a checklist action and a focus session. Use the pitch builder when you need to explain the project to a supervisor.

### For an idea that feels too ordinary

Bring it to Collision lab with a completely different hobby or observation. Try a paper-only or offline-only constraint. Ask the first-user lens what someone would actually do with it. Keep the promising fragment as a new branch rather than destroying the original.

### For too many unfinished ideas

Open the stage board. Park work you do not want to commit to now. Star a few possibilities that still matter. Give one of them a small next move. Write a capsule about the rest so that letting them rest is an intentional choice.

### For a writer or learner

Capture a story seed or borrowed pattern. Use Atlas to find recurring words and manually connect the useful relationships. Take a short focus session to make one paragraph or example. End a review with the question you want to return to next.

## Keep the work portable

Export includes all original tables plus projects, memberships, tasks, experiments, capsules, focus sessions, reviews, saved views, and draft metadata. Readable idea Markdown includes the task list and experiment records. The attachment manifest names absent files rather than silently pretending they were exported. The archive is an archival handoff, not a full-restore format implemented in this version.

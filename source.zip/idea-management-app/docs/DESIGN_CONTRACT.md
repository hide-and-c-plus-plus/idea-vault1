# Idea Vault / Creative Studio

The product is a private workshop for unfinished thoughts. The primary action is always capture; the secondary action is making one idea more useful. The app must work without a server, paid API, or account.

## Workflow and hierarchy

- Today: one invitation to capture, today's prompt, active work, and resurfaced thoughts.
- Vault: search, saved views, favorites, filters, and an optional stage board.
- Studio: hands-on tools that create real notes, links, tasks, experiments, and sessions.
- Atlas: an interactive map of explicitly linked ideas, plus explainable keyword discoveries.
- Review: activity, milestones, a guided reset, and a written reflection.
- Inbox stays reachable from Today and Vault. Projects, capsules, and focus are full screens.

## Visual language

Use the existing midnight surfaces with lavender, warm amber, and mint accents. Big quiet headings, small uppercase context labels, clear section spacing, and outlined controls. Cards represent an idea, a saved object, or an actionable tool; decoration must not masquerade as data. Narrow screens use one column and horizontal chip rails. Large screens constrain reading width. The map gets a fixed plotting area with an equivalent navigable list.

## Interaction requirements

At least 48-point touch targets for actions. Accessible labels and selected/disabled states. Every asynchronous page needs loading, empty, error, and retry states. Submission buttons prevent duplicate saves. Drafts survive navigation. Save completion is visible. No pretend AI output: prompts are authored creative exercises; connections are explicit links or explained word overlap. Demo content is opt-in and labeled.

## Observable acceptance

Existing captures remain readable after migration. A collision saves a new idea and two lineage links atomically. A task toggles and survives reload. Experiments keep success criteria separate from observed results. A capsule cannot be opened early through its normal UI. Focus sessions recover their deadline after restart and record actual elapsed time when ended early. Export contains every new table. Empty vaults have useful next steps. No required feature needs the network.

# Idea Vault — Creative Studio edition

An offline workshop for capturing rough thoughts, finding surprising connections, and turning a few of them into something real. This is an expanded version of the supplied Expo / React Native app, with a migration that preserves the original database.

## Start here

Use Node.js 24 and npm. Android is the primary target. A development build is required for the complete native experience.

```bash
cd idea-management-app
npm ci
npm run typecheck
npm test
npm run prebuild
npm run android
```

After installing the development build on your phone, subsequent JavaScript development uses:

```bash
npm start
```

Android Studio, an Android SDK, and a configured emulator or USB-connected phone are needed for local Android builds. The existing EAS development / preview APK profiles are also included; cloud builds require your own Expo account and project configuration. No signing key, account credential, generated APK, or node_modules directory is included.

A browser preview is available with `npm run web`. Android remains the reference platform for microphone recording, camera capture, incoming shares, notifications, and file sharing. The browser uses its own storage, separate from the phone. Expo's SQLite web implementation requires cross-origin isolation; `metro.config.js` includes the required development-server headers and WASM asset support. If the browser SQLite build omits FTS5, search falls back to literal substring matching over the indexed text; Android retains full-text ranking.

## Take a creative tour

1. Capture two rough ideas. Or open Settings and explicitly add the labeled playground examples.
2. Open **Studio → Collision lab**. Choose two ingredients, try a bridge prompt, and write the surprising combination. Save a new idea with both parent connections.
3. Open **Atlas**. Center the map on the new idea and follow its lineage. Review shared-word suggestions before connecting anything.
4. Add one tiny action to the idea. Give it a short session in the **Focus room**.
5. Put an uncertain assumption on the **Experiment bench**. Define the success signal before recording an outcome.
6. Let the idea rest in a **Time capsule**, gather related ideas in a **Project room**, or return for a **Review** reflection.

See [the feature guide](docs/CREATIVE_PLAYBOOK.md) for every implemented feature and suggested ways to combine them.

## What changed

- A redesigned five-tab shell: Today, Vault, Studio, Atlas, Review, with a reachable Inbox and a dedicated Capture action.
- Collision lab, seven-card remix deck, seven perspective lenses, constraint roulette, assumption ladder, editable one-page pitch, and twelve capture starters.
- Projects, shortlists, energy filters, stage board, saved searches, per-idea checklists, and a visible event history.
- Recoverable focus sessions, time capsules, experiment observations, activity calendar, creative milestones, and written review history.
- Real image previews, file sharing, single-idea Markdown sharing, text/Markdown import, and a complete export of the new Studio tables.
- SQLite migration 2, serialized transactions, atomic capture plus attachment plus draft clearing, safer Unicode search, cancellation of trashed reminders, and opt-in sample data.

All creativity tools work locally. Prompts are curated exercises, pitches are editable templates assembled from your notes, and related-idea suggestions use explainable shared words. There is no remote model, invented AI analysis, analytics service, or login.

## Checks

```bash
npm run typecheck
npm test
npx expo export --platform android --output-dir dist/android
```

The tests run production repository functions against real in-memory SQLite (including FTS5 and foreign keys). Only device I/O is adapted. They cover populated-v1 migration, collisions and rollback, task and project persistence, search, capsules, focus timing, trash, exports, and deterministic domain helpers. See [validation notes](docs/VALIDATION.md) for the actual checks performed and the remaining device checklist.

## Data ownership and limits

- Existing `idea-vault.db` data upgrades in place. Keep the same Android application ID and signing identity when upgrading an installed app. Uninstalling first can remove its local data.
- Export creates a ZIP with canonical JSON, readable per-idea Markdown, and available attachments. Missing attachment IDs are listed in a manifest. Native sharing lets you save it somewhere durable.
- Import accepts one text or Markdown note up to 1 MB. It does **not** restore the complete exported ZIP.
- Time capsules are a creative delay, not a security feature. Full letters are plain local data and are included in exports.
- Focus uses a persisted wall-clock deadline and keeps actual elapsed seconds, capped at the planned length. It is not a background alarm or proof of uninterrupted attention. Manual device-clock changes can affect timing.
- The native database and media are not encrypted by this app. No biometric gate, cloud sync, transcription, semantic embeddings, widget, or collaboration backend is claimed.
- Search and board views show at most 200 matches; Atlas and idea pickers inspect up to 500 ideas. Atlas draws a focal idea and up to seven neighbors. Refine the search for large vaults.

## Source map

| Location                | Responsibility                                                  |
| ----------------------- | --------------------------------------------------------------- |
| `src/app`               | Expo Router screens and navigation                              |
| `src/components/studio` | Shared forms, cards, headers, loading/empty states, idea picker |
| `src/domain/prompts.ts` | Authored templates and creative prompt decks                    |
| `src/domain/logic.ts`   | Pure search, calendar, timer, shuffle, and layout helpers       |
| `src/db/migrations.ts`  | Original schema plus non-destructive Studio migration           |
| `src/db/repositories`   | Persistent idea and Studio workflows                            |
| `src/db/write.ts`       | Serialized transaction queue                                    |
| `src/hooks/useAsync.ts` | Async loading, submission feedback, recoverable form drafts     |
| `src/services`          | Device media, reminders, import, export, maintenance            |
| `tests`                 | Domain tests and real-SQLite repository integration tests       |

Official API references consulted: [Expo SDK 57 SQLite](https://docs.expo.dev/versions/v57.0.0/sdk/sqlite/) and [Expo SDK 57 Sharing](https://docs.expo.dev/versions/v57.0.0/sdk/sharing/).
